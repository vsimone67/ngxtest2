To Install Template (one time) Run
    dotnet new -i .\template.Service

To UnInstall Run
    dotnet new -u FULLPATHINCLUDINGDRIVE\template.Service

To List all templates and show their uninstall command
    dotnet new -u