using System;

namespace template.service50.Infrastructure
{
    public class MyInfrastructure
    {

    }
}
