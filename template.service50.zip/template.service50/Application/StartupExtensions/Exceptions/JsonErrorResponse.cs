﻿namespace template.Service.Extensions
{
    public class JsonErrorResponse
    {
        public string Message { get; set; }

        public object DeveloperMessage { get; set; }
    }

}
