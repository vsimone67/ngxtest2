using System;

namespace template.Service.Application.Dto
{
    public class MyDto
    {

    }
}
