using System;

namespace template.Service.Domain.Entities
{
    public class MyEntity
    {

    }
}
