rm readme.txt
rm application/commands/*
rm application/controllers/*
rm application/dto/*
rm application/queries/*
rm domain/entities/*
rm infrastructure/*
rm persistence/context/*
rm persistence/dbservice/databaseservice.cs
rm persistence/dbservice/idatabaseservice.cs

