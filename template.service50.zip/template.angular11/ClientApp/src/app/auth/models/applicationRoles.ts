
export enum ApplicationRoles {
  Adminstrator = "Administrator"
}
