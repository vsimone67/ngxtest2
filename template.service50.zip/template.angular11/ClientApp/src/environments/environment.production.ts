export const environment = {
  production: true,
  authorizationApiUrl: "http://USVDEVEVRSTAS3:3356/api",
  apiGatewayUrl: "http://USVDEVEVRSTAS3:3351"
};
