export const environment = {
  production: false,
  authorizationApiUrl: "http://localhost:3356/api",
  apiGatewayUrl: "http://localhost:3351"
};
