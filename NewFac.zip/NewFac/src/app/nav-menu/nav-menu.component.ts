import { Component } from "@angular/core";
import { supportedLanguages } from "@models/Constants/site-constants";
import { LanguageTranslationService } from "@shared/localization/language-translation.service";

@Component({
  selector: "app-nav-menu",
  templateUrl: "./nav-menu.component.html",
  styleUrls: ["./nav-menu.component.css"],
})
export class NavMenuComponent {
  collapsed: boolean = false;
  languages;

  constructor(private languageTranlationService: LanguageTranslationService) {
    this.languages = supportedLanguages;
  }

  selectLanguage(language: string) {
    this.languageTranlationService.loadNewLanguage(language);
  }
}
