import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import {
  UnderwritingEmployeeListComponent,
  UnderwritingEmployeeComponent,
  FacImparementComponent,
  UnderwritingSeriesListComponent,
  UnderwritingSeriesMainComponent
} from "@admin/components/index";
import { AuthGuard } from "@auth/service/auth-guard";
import { Role } from "@models/Auth/role";

const routes: Routes = [
  {
    path: "uwemployeelist",
    data: {
      breadcrumb: "admin.uwEmployeeList.breadcrumb",
      roles: [Role.Facultative],
    },
    component: UnderwritingEmployeeListComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "uwemployee/:id/:readOnly",
    data: {
      breadcrumb: "admin.uwEmployee.breadcrumb",
      parentUrl: "#/uwemployeelist",
      parentName: "admin.uwEmployee.parentBreadcrumb",
      roles: [Role.Facultative],
    },
    component: UnderwritingEmployeeComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "uwimparement",
    data: { breadcrumb: "UW Imparement" },
    component: FacImparementComponent,
  },
  {
    path: "uwserieslist",
    data: { breadcrumb: "Underwriting Series" },
    component: UnderwritingSeriesListComponent,
  },
  {
    path: "uwseries/:id/:readonly",
    data: {
      breadcrumb: "admin.uwSeries.breadcrumb",
      parentUrl: "#/uwserieslist",
      parentName: "admin.uwSeries.parentBreadcrumb",
      roles: [Role.Facultative],
    },
    component: UnderwritingSeriesMainComponent,
    canActivate: [AuthGuard],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdminRoutingModule {}
