"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
var underwriting_employee_list_component_1 = require("./underwriting-employee-list/underwriting-employee-list.component");
var underwriting_series_component_1 = require("./underwriting-series/underwriting-series-main.component");
var underwriting_employee_component_1 = require("./underwriting-employee/underwriting-employee.component");
var underwriting_employee_series_component_1 = require("./underwriting-employee/underwriting-employee-series/underwriting-employee-series.component");
exports.components = [underwriting_employee_list_component_1.UnderwritingEmployeeListComponent, underwriting_series_component_1.UnderwritingSeriesComponent, underwriting_employee_component_1.UnderwritingEmployeeComponent, underwriting_employee_series_component_1.UnderwritingEmployeeSeriesComponent];
__export(require("./underwriting-employee-list/underwriting-employee-list.component"));
__export(require("./underwriting-series/underwriting-series-main.component"));
__export(require("./underwriting-employee/underwriting-employee.component"));
__export(require("./underwriting-employee/underwriting-employee-series/underwriting-employee-series.component"));
//# sourceMappingURL=index.js.map
