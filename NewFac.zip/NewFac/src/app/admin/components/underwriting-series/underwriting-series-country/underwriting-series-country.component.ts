import { Component, OnInit, Input } from "@angular/core";
import { UnderwritingSeriesCountryModel } from "@models/CRM/underwritingSeriesCountryModel";
import { GridOptions, ColDef } from "ag-grid-community";
import { ConfirmationService } from "primeng/api";
import { UnderwritingSeriesService } from "@admin/service/underwritingSeries.service";
import { TranslateService } from "@ngx-translate/core";
import { LanguageTranslationService } from "@shared/localization/language-translation.service";
import { ImageButtonCellComponent } from "@shared/components/grid";
import { CodeModel } from "@models/Common//codeModel";
import { EmployeeModel } from "@models/CRM/employeeModel";
import { FacultativeService } from "@fac/services/facultative.service";

@Component({
  selector: "underwriting-series-country",
  templateUrl: "./underwriting-series-country.component.html",
  styleUrls: ["./underwriting-series-country.component.css"],
})
export class UnderwritingSeriesCountryComponent implements OnInit {
  @Input() countries: Array<UnderwritingSeriesCountryModel>;
  @Input() readOnly: boolean;

  private gridOptions: GridOptions;
  private columnDefs: Array<ColDef>;
  private _displayDialog: boolean;
  private _countryToEdit: UnderwritingSeriesCountryModel;
  private _countries: Array<CodeModel>;
  private _selectedCountry: CodeModel;
  private _supervisors: Array<EmployeeModel>;
  private _selectedSupervisor: EmployeeModel;
  private _overLimitAuthorization: Array<CodeModel>;
  private _selectedOverLimitAuthorization: CodeModel;
  private _mode: string;
  private _gridApi: any;

  private formatter;

  constructor(
    private _confirmService: ConfirmationService,
    private _facService: FacultativeService,
    private translate: TranslateService,
    private _languageTransalationService: LanguageTranslationService
  ) {
    this.gridOptions = {
      defaultColDef: {
        sortable: true,
        resizable: false,
      },
      pagination: false,
      rowHeight: 48,
      headerHeight: 60,
    };
    this._displayDialog = false;
    this._countries = new Array<CodeModel>();
    this._supervisors = new Array<EmployeeModel>();
    this._overLimitAuthorization = new Array<CodeModel>();
  }

  ngOnInit() {
    this.formatter = new Intl.NumberFormat(
      this._languageTransalationService.languageParameters.countryCode,
      {
        style: "currency",
        currency: this._languageTransalationService.languageParameters
          .currencyFormat,
        maximumFractionDigits: 2,
      }
    );
    this.columnDefs = this.createColumnDefs();
  }
  createColumnDefs(): ColDef[] {
    console.log(this.countries);
    return [
      { headerName: this.translate.instant("admin.uwSeries.country.grid.countryName"), field: "countryCode.codeName" },
      //{headerName: "Supervisor", field: "seriesSupervisorEmployee.lastName"  },
      {
        headerName: this.translate.instant("admin.uwSeries.country.grid.supervisorName"),
        valueGetter: function (parmas) {
          return (
            parmas.data.seriesSupervisorEmployee.firstName +
            " " +
            parmas.data.seriesSupervisorEmployee.lastName
          );
        },
      },
      {
        headerName: this.translate.instant("admin.uwSeries.country.grid.uwAssignable"),
        field: "underwriterAssignable",
        valueFormatter: (data) => (data.value ? "Yes" : "No"),
      },
      { headerName: "Jumbo Limit Amount", field: "jumboAmountLimit" },
      {
        headerName: this.translate.instant("admin.uwSeries.country.grid.MIBAuthorized"),
        field: "underwriterAssignable",
        valueFormatter: (data) => (data.value ? "Yes" : "No"),
      },
      {
        headerName: this.translate.instant("admin.uwSeries.country.grid.overLimit"),
        field: "overLimitAuthorization.codeName",
      },
      {
        headerName: this.translate.instant("admin.uwSeries.country.grid.decisionHandleManually"),
        field: "isDecisionManuallyHandled",
        valueFormatter: (data) => (data.value ? "Yes" : "No"),
      },
      {
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onEditCountry.bind(this),
          icon: "pi-pencil",
        },
      },
      {
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onDeleteCountry.bind(this),
          icon: "pi-times",
        },
      },
    ];
  }
  onGridReady(params) {
    params.api.sizeColumnsToFit(); // size grid to take up all availibe realestate
    this._gridApi = params.api;
  }

  onAddCountry() {}
  onEditCountry() {}
  onDeleteCountry() {}
}
