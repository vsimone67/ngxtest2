import { Component, OnInit, ViewChild } from "@angular/core";
import { UnderwritingSeriesModel } from "@models/CRM/underwritingSeriesModel";
import { UnderwritingSeriesService } from "@admin/service/underwritingSeries.service";
import { TranslateService } from "@ngx-translate/core";
import { LanguageTranslationService } from "@shared/localization/language-translation.service";
import { AdminService } from "@admin/service/admin.service";
import { ActivatedRoute, ParamMap } from "@angular/router";
import { MessageService } from "primeng/api";
import { LocalStorageService } from "@shared/services/localStorage-service";
import { UnderwritingSeriesCountryComponent } from "@admin/components/index";
import { UnderwritingSeriesCountryModel } from "@models/CRM/underwritingSeriesCountryModel";

@Component({
  selector: "underwriting-series-main",
  templateUrl: "./underwriting-series-main.component.html",
  styleUrls: ["./underwriting-series-main.component.css"],
})
export class UnderwritingSeriesMainComponent implements OnInit {
  //@ViewChild(UnderwritingSeriesCountryComponent, { static: false }) countries;

  private _uwseries: UnderwritingSeriesModel;
  private _uwsCountry: Array<UnderwritingSeriesCountryModel>;
  private _isReadOnly: boolean;

  constructor(
    private _underwritingSeriesService: UnderwritingSeriesService,
    private translate: TranslateService,
    private _languageTranslationService: LanguageTranslationService,
    //    private _adminService: AdminService,
    private _route: ActivatedRoute,
    private _messageService: MessageService,
    private lStorage: LocalStorageService
  ) {
    this._uwseries = <UnderwritingSeriesModel>{};
    //this._uwsCountry = Array<UnderwritingSeriesCountryModel>();
  }

  async ngOnInit() {
    let id = this._route.snapshot.paramMap.get("id");
    let readOnly = this._route.snapshot.paramMap.get("readOnly");

    this._isReadOnly = readOnly === "1";
    this._uwseries = await this._underwritingSeriesService.getUnderwritingSeriesById(id);
  }
}
