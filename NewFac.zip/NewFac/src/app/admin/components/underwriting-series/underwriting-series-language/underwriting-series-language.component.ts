import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'underwriting-series-language',
  templateUrl: './underwriting-series-language.component.html',
  styleUrls: ['./underwriting-series-language.component.css']
})
export class UnderwritingSeriesLanguageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
