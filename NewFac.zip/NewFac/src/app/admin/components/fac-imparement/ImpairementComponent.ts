import { Component } from "@angular/core";
import { ImageButtonCellComponent } from "@shared/components/grid";

export class ImpairementComponent extends ImageButtonCellComponent {
    agInit(params: any): void {

        // if the code count is 0 hide the delete button
        if (params.data.facApplicantImpairmentImpairmentCodeCount === 0) {
            this.isVisible = false;
        }
        super.agInit(params);
    }
}
