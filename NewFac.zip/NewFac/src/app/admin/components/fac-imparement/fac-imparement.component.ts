import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { GridOptions, ColDef } from "ag-grid-community";
import { ImageButtonCellComponent } from "@shared/components/grid";
import { AdminService } from "@admin/services/admin.service";
import { ImpairmentImpairmentCodeModel } from "@models/Impairment/impairmentImpairmentCodeModel";
import { ConfirmationService, MessageService } from "primeng/api";
import { ImpairmentModel } from "@models/Impairment/impairmentModel";
import { ImpairementComponent } from './ImpairementComponent';

@Component({
  encapsulation: ViewEncapsulation.None,
  selector: "fac-imparement",
  templateUrl: "./fac-imparement.component.html",
  styleUrls: ["./fac-imparement.component.css"]
})
export class FacImparementComponent implements OnInit {
  private columnDefs: Array<ColDef>;
  private rowData: Array<ImpairmentImpairmentCodeModel>;
  private gridOptions: GridOptions;
  private _displayDialog: boolean;
  private _gridApi: any;
  private _mode: string;
  private _impairmentToEdit: ImpairmentImpairmentCodeModel;
  private _impairementGuide: Array<ImpairmentModel>;
  private _selectedImpairementGuide: ImpairmentModel;

  constructor(
    private _confirmService: ConfirmationService,
    private _adminService: AdminService,
    private _messageService: MessageService
  ) {
    this._displayDialog = false;
    this._impairmentToEdit = <ImpairmentImpairmentCodeModel>{};
    this._impairementGuide = new Array<ImpairmentModel>();
  }

  async ngOnInit() {
    this.columnDefs = [
      {
        headerName: "Impairment Name",
        field: "impairmentName",
        filter: "agTextColumnFilter"
      },
      {
        headerName: "Sort Order",
        field: "sortOrder",
        cellClass: "text-left",
        filter: "agTextColumnFilter"
      },
      {
        headerName: "UW Guide URL",
        field: "impairmentUWGuideURL",
        cellClass: "text-left"
      },
      {
        headerName: "Display",
        field: "displayImpairment",
        cellClass: "text-left",
        valueFormatter: data => (data.value ? "Yes" : "No")
      },
      {
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onEditImpairement.bind(this),
          icon: "pi-pencil"
        },
        width: 35
      },
      {
        headerName: "",
        cellRendererFramework: ImpairementComponent,
        cellRendererParams: {
          onClick: this.onDeleteImpairment.bind(this),
          icon: "pi-times"
        },
        width: 35
      }
    ];

    this.rowData = await this._adminService.getFacImpiarements();
  }

  onGridReady(params) {
    params.api.sizeColumnsToFit(); // size grid to take up all availibe realestate
    this._gridApi = params.api;
  }

  async onAddImpairment() {
    this._mode = "Add";
    this._impairmentToEdit = <ImpairmentImpairmentCodeModel>{};
    this._impairmentToEdit.displayImpairment = true;
    this._impairmentToEdit.impairmentName = "";
    this._selectedImpairementGuide = undefined;
    await this.loadDropDowns();
    this._displayDialog = true;
  }

  public async onEditImpairement(data) {
    this._mode = "Edit";
    this._impairmentToEdit = data.rowData;
    await this.loadDropDowns();
    this._selectedImpairementGuide = this._impairementGuide.find(
      impairement =>
        impairement.impairmentId === this._impairmentToEdit.impairmentId
    );
    this._displayDialog = true;
  }

  public onDeleteImpairment(data) {
    this._confirmService.confirm({
      message: "Are you sure that you want to remove this impairment?",
      header: "Confirmation",
      icon: "pi pi-exclamation-triangle",
      accept: () => {
        this.rowData = this.rowData.filter(obj => obj !== data.rowData);
        this._adminService.deleteImpairement(data);
        this.displayMessage("Impairement has been deleted");

      }
    });
  }

  private async loadDropDowns() {
    if (this._impairementGuide.length == 0) {
      this._impairementGuide = await this._adminService.getFacImpairmentCodes();
    }
  }

  private async impairmentUpdateCompleted() {
    this._displayDialog = false;

    if (this._mode === "Add") {
      this._impairmentToEdit.impairmentId = this._selectedImpairementGuide.impairmentId;
      await this._adminService.addImpairement(this._impairmentToEdit);
      this._gridApi.updateRowData({ add: [this._impairmentToEdit] });
      this.rowData.push(this._impairmentToEdit);
      this.displayMessage("Impairement has been added");
    } else {
      await this._adminService.updateImpairement(this._impairmentToEdit);
      var row = this.rowData.findIndex(
        series => series.impairmentId === this._impairmentToEdit.impairmentId
      );

      if (row >= 0) {
        var rowNode = this._gridApi.getDisplayedRowAtIndex(row);
        rowNode.setDataValue("impairmentName", this._impairmentToEdit.impairmentName);
        rowNode.setDataValue("impairmentUWGuideURL", this._selectedImpairementGuide.impairmentUWGuideURL);
        rowNode.setDataValue("sortOrder", this._impairmentToEdit.sortOrder);
        rowNode.setDataValue("displayImpairment", this._impairmentToEdit.displayImpairment);
        this.displayMessage("Impairement has been updated");
      }


    }
  }

  private displayMessage(message: string) {
    this._messageService.add({ severity: 'success', detail: message });
  }


}

