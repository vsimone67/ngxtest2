import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { AdminService } from "@admin/service/admin.service";
import { ImageButtonCellComponent } from "@shared/components/grid";
import { Router } from "@angular/router";
import * as moment from "moment";
import { GridOptions, ColDef } from "ag-grid-community";
import { EmployeeUnderwritingModel } from "@models/CRM//employeeUnderwritingModel";
import { TranslateService } from "@ngx-translate/core";
import { agGridTranslateGridItems } from "@shared/localization/agGridTranslate";
import { LanguageTranslationService } from "@shared/localization/language-translation.service";
import { PagedListModel } from "@models/paged-list.model";

@Component({
  selector: "app-underwriting-employee-list",
  templateUrl: "./underwriting-employee-list.component.html",
  styleUrls: ["./underwriting-employee-list.component.css"],
  encapsulation: ViewEncapsulation.None, // add this to get the css styles of primng to work in the local css file
})
export class UnderwritingEmployeeListComponent implements OnInit {
  public columnDefs: Array<ColDef>;
  public rowData: Array<EmployeeUnderwritingModel>;
  public gridOptions: GridOptions;
  private currentPage: number;
  private pageSize: number;
  public pagedInfo: PagedListModel<EmployeeUnderwritingModel>;
  public pageTemplate: string;
  constructor(
    private _adminService: AdminService,
    private _router: Router,
    private translate: TranslateService,
    private _languageTranslationService: LanguageTranslationService
  ) {
    // primeng paginnator tempalte
    this.pageTemplate = `${this.translate.instant(
      "agGrid.page"
    )} {currentPage} ${this.translate.instant("agGrid.of")} {totalPages}`;

    // grid options
    this.gridOptions = {
      defaultColDef: {
        sortable: true,
        resizable: false,
      },
      pagination: false,
      paginationAutoPageSize: true,
      localeTextFunc: agGridTranslateGridItems,
    };

    this.currentPage = 1;
    this.pageSize = 25;

    this.pagedInfo = new PagedListModel<EmployeeUnderwritingModel>(); // create instance so we do not get underfined errros from the html page
  }

  async ngOnInit() {
    this.createColumnDefs();

    await this.getPagedData(this.currentPage, this.pageSize);
  }

  createColumnDefs() {
    // Ensure all translations are loaded (translate returns an observable)
    this.translate.get("admin.uwEmployeeList.grid").subscribe(() => {
      this.columnDefs = [
        {
          headerName: this.translate.instant(
            "admin.uwEmployeeList.grid.firstNameHeader"
          ),
          field: "employee.firstName",
          filter: "agTextColumnFilter",
        },
        {
          headerName: this.translate.instant(
            "admin.uwEmployeeList.grid.lastNameHeader"
          ),
          field: "employee.lastName",
          cellClass: "text-left",
          filter: "agTextColumnFilter",
        },
        {
          headerName: this.translate.instant(
            "admin.uwEmployeeList.grid.dailyCasesHeader"
          ),
          field: "dailyFacCaseAssignments",
          cellClass: "text-left",
        },
        {
          headerName: this.translate.instant(
            "admin.uwEmployeeList.grid.maxCaseHeader"
          ),
          field: "maximumFacCaseCount",
          cellClass: "text-left",
        },
        {
          headerName: this.translate.instant(
            "admin.uwEmployeeList.grid.lastAssignmentHeader"
          ),
          field: "lastTaskAssignedDate",
          cellClass: "text-left",
          valueFormatter: (data) =>
            (data.value &&
              moment(data.value).format(
                this._languageTranslationService.languageParameters
                  .dateFormatGrid
              )) ||
            "",
        },
        {
          headerName: "",
          cellRendererFramework: ImageButtonCellComponent,
          cellRendererParams: {
            onClick: this.onGetEmployeeReadOnly.bind(this),
            icon: "pi-copy",
          },
          width: 35,
        },
        {
          headerName: "",
          cellRendererFramework: ImageButtonCellComponent,
          cellRendererParams: {
            onClick: this.onGetEmployeeForEdit.bind(this),
            icon: "pi-pencil",
          },
          width: 35,
        },
      ];
    });
  }

  get rowCount(): number {
    return this.rowData.length;
  }

  async getPagedData(currentPage: number, pageSize: number) {
    this.pagedInfo = await this._adminService.getAllUwEmployees(
      currentPage,
      pageSize
    );

    this.rowData = this.pagedInfo.payload;
  }

  async onNextPageClicked(event) {
    await this.getPagedData(event.page + 1, event.rows);
  }

  onGridReady(params) {
    params.api.sizeColumnsToFit(); // size grid to take up all availibe realestate
  }

  onGetEmployeeReadOnly(data) {
    this._router.navigate([`uwemployee/` + data.rowData.employeeId + "/1"]);
  }

  onGetEmployeeForEdit(data) {
    this._router.navigate([`uwemployee/` + data.rowData.employeeId + "/0"]);
  }
}
