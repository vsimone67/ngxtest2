import {
  Component,
  OnInit,
  Input,
  SimpleChanges,
  OnChanges,
  ViewChild,
} from "@angular/core";
import {
  AbstractControl,
  NG_VALIDATORS,
  Validator,
  ValidationErrors,
} from "@angular/forms";
import { AdminService } from "@admin/service/admin.service";
import { ImageButtonCellComponent } from "@shared/components/grid";
import { Router, ActivatedRoute } from "@angular/router";
import * as moment from "moment";
import { GridOptions, ColDef } from "ag-grid-community";
import { ConfirmationService } from "primeng/api";
import { UnderwritingSeriesModel } from "@models/CRM/underwritingSeriesModel";
import { UnderwritingSeriesService } from "@admin/service/underwritingSeries.service";
import { User } from "@models/Auth/user";
import { SiteConstants } from "@models/Constants/site-constants";
import { MessageService } from "primeng/api";
import { LocalStorageService } from "@shared/services/localStorage-service";
import { TranslateService } from "@ngx-translate/core";
import { LanguageTranslationService } from "@shared/localization/language-translation.service";
import { agGridTranslateGridItems } from "../../../shared/localization/agGridTranslate";

@Component({
  selector: "underwriting-series-list",
  templateUrl: "./underwriting-series-list.component.html",
  styleUrls: ["./underwriting-series-list.component.css"],
})
export class UnderwritingSeriesListComponent implements OnInit {
  @Input() SeriesId: string;
  public columnDefs: Array<ColDef>;
  public gridOptions: GridOptions;
  public _uwseries: Array<UnderwritingSeriesModel>;
  private _gridApi: any;
  public _uwseriesToEdit: UnderwritingSeriesModel;
  public _mode: string;
  public _displayDialog: boolean;

  constructor(
    public _underwritingSeriesService: UnderwritingSeriesService,
    public _route: ActivatedRoute,
    public _router: Router,
    public _messageService: MessageService,
    public lStorage: LocalStorageService,
    public translate: TranslateService,
    public _languageTransalationService: LanguageTranslationService
  ) {
    this.gridOptions = {
      defaultColDef: {
        sortable: true,
        resizable: false,
      },
      pagination: false,
      localeTextFunc: agGridTranslateGridItems,
    };

    this._displayDialog = false;
    this._uwseriesToEdit = <UnderwritingSeriesModel>{};
  }

  async ngOnInit() {
    this.createColumnDefs();
    this._uwseries = await this._underwritingSeriesService.getAllUnderwritingSeries();
  }

  createColumnDefs() {
    // Ensure all translations are loaded (translate returns an observable)
    this.translate.get("admin.UWSeriesList.grid").subscribe(() => {
      this.columnDefs = [
        {
          headerName: this.translate.instant(
            "admin.UWSeriesList.grid.nameHeader"
          ),
          field: "seriesName",
          filter: "agTextColumnFilter",
          editable: true,
        },
        {
          headerName: this.translate.instant(
            "admin.UWSeriesList.grid.sequenceHeader"
          ),
          field: "seriesSequence",
          cellClass: "text-right",
        },
        {
          headerName: this.translate.instant(
            "admin.UWSeriesList.grid.sortOrderHeader"
          ),
          field: "seriesSortSequence",
          cellClass: "text-right",
        },
        {
          headerName: "",
          cellRendererFramework: ImageButtonCellComponent,
          cellRendererParams: {
            onClick: this.onEditSeries.bind(this),
            icon: "pi-pencil",
          },
          width: 30,
        },
        {
          headerName: "",
          cellRendererFramework: ImageButtonCellComponent,
          cellRendererParams: {
            onClick: "",
            icon: "pi-times",
          },
          width: 30,
        },
      ];
    });
  }

  onGridReady(params) {
    params.api.sizeColumnsToFit(); // size grid to take up all availibe realestate
    this._gridApi = params.api;
  }

  async ngOnChanges(changes: SimpleChanges) {
    this._uwseries = await this._underwritingSeriesService.getAllUnderwritingSeries();
  }

  // async onEditSeries(data) {
  //   this._mode = "Edit";
  //   console.log(this._mode);
  //   this._uwseriesToEdit = data.rowData;
  //   console.log(this._uwseriesToEdit.seriesName);
  //   this._displayDialog = true;
  // }

  async onEditSeries(data) {
    this._router.navigate([`uwseries/` + data.rowData.seriesId + "/1"]);
  }

  public onAddSeries() {
    this._mode = "Add";
    this._uwseriesToEdit = <UnderwritingSeriesModel>{};
    this._displayDialog = true;
  }

  async saveSeries() {
    this._displayDialog = false;

    var currentUser: User = JSON.parse(
      this.lStorage.getValue(SiteConstants.UserToken)
    );
    this._uwseriesToEdit.modifiedBy = currentUser.userId;

    await this._underwritingSeriesService.saveSeries(this._uwseriesToEdit);

    let input = new FormData();
    input.append("SeriesName", this._uwseriesToEdit.seriesName);
    input.append(
      "SeriesSequence",
      this._uwseriesToEdit.seriesSequence.toString()
    );
    input.append(
      "SeriesSortSequence",
      this._uwseriesToEdit.seriesSortSequence.toString()
    );

    var row = this._uwseries.findIndex(
      (series) => series.seriesId === this._uwseriesToEdit.seriesId
    );

    if (row >= 0) {
      this._uwseries[row] = this._uwseriesToEdit;
      var rowNode = this._gridApi.getDisplayedRowAtIndex(row);
      this._gridApi.setRowData(this._uwseries);
      rowNode.setDataValue("seriesName", this._uwseriesToEdit.seriesName);
      rowNode.setDataValue(
        "seriesSequence",
        this._uwseriesToEdit.seriesSequence
      );
      rowNode.setDataValue(
        "seriesSortSequence",
        this._uwseriesToEdit.seriesSortSequence
      );
    }

    this._messageService.add({
      severity: "success",
      summary: this.translate.instant(
        "admin.uwEmployee.seriesList.saveMessageSummary"
      ),
      detail: this.translate.instant(
        "admin.uwEmployee.seriesList.saveMessageDetail"
      ),
    });
  }
}
