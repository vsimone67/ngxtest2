import { Component, OnInit, Input } from "@angular/core";
import { CodeModel } from "@models/Common/codeModel";

@Component({
  selector: "underwriting-employee-languages",
  templateUrl: "./underwriting-employee-languages.component.html",
  styleUrls: ["./underwriting-employee-languages.component.css"],
})
export class UnderwritingEmployeeLanguagesComponent implements OnInit {
  private _draggedLanguage: CodeModel;
  @Input() languagesUsed: Array<CodeModel>;
  @Input() languages: Array<CodeModel>;
  @Input() readOnly: boolean;

  constructor() {}

  ngOnInit() {}
  allLanguagesDragStart(event, language: CodeModel) {
    this._draggedLanguage = language;
  }

  dropAllLanguages(event) {
    if (this._draggedLanguage) {
      this.languagesUsed = this.languagesUsed.filter(
        (obj) => obj !== this._draggedLanguage
      );
      this.languages.push(this._draggedLanguage);
      this._draggedLanguage = null;
    }
  }

  allLanguagesDragEnd(event) {
    this._draggedLanguage = null;
  }

  languageDragStart(event, language: CodeModel) {
    this._draggedLanguage = language;
  }

  dropLanguage(event) {
    if (this._draggedLanguage) {
      this.languages = this.languages.filter(
        (obj) => obj !== this._draggedLanguage
      );
      this.languagesUsed.push(this._draggedLanguage);
      this._draggedLanguage = null;
    }
  }

  languageDragEnd(event) {
    this._draggedLanguage = null;
  }
}
