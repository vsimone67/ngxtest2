import { Component, OnInit, Input } from "@angular/core";
import { EmployeeUnderwritingSeriesModel } from "@models/CRM//employeeUnderwritingSeriesModel";
import { GridOptions, ColDef } from "ag-grid-community";
import { ImageButtonCellComponent } from "@shared/components/grid";
import { ConfirmationService } from "primeng/api";
import { UnderwritingSeriesModel } from "@models/CRM/underwritingSeriesModel";
import { UnderwritingSeriesService } from "@admin/services/underwritingSeries.service";

@Component({
  selector: "underwriting-employee-series",
  templateUrl: "./underwriting-employee-series.component.html",
  styleUrls: ["./underwriting-employee-series.component.css"],
})
export class UnderwritingEmployeeSeriesComponent implements OnInit {
  @Input() series: Array<EmployeeUnderwritingSeriesModel>;
  @Input() readOnly: boolean;

  private gridOptions: GridOptions;
  private columnDefs: Array<ColDef>;
  private _displayDialog: boolean;
  private _seriesToEdit: EmployeeUnderwritingSeriesModel;
  private _series: Array<UnderwritingSeriesModel>;
  private _selectedSeries: UnderwritingSeriesModel;
  private _mode: string;
  private _gridApi: any;

  constructor(
    private _confirmService: ConfirmationService,
    private _uWSeriesService: UnderwritingSeriesService
  ) {
    this.gridOptions = {
      defaultColDef: {
        sortable: true,
        resizable: false,
      },
      pagination: false,
    };
    this._displayDialog = false;
    this._series = new Array<UnderwritingSeriesModel>();
    this._seriesToEdit = <EmployeeUnderwritingSeriesModel>{};
  }

  ngOnInit() {
    this.columnDefs = this.createColumnDefs();
  }

  createColumnDefs() {
    return [
      { headerName: "Series Name", field: "seriesName" },
      {
        headerName: "Allow Decision",
        field: "allowDecision",
        valueFormatter: (data) => (data.value ? "Yes" : "No"),
      },
      {
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onEditSeries.bind(this),
          icon: "pi-pencil",
        },
        width: 35,
      },
      {
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onDeleteSeries.bind(this),
          icon: "pi-times",
        },
        width: 35,
      },
    ];
  }

  public async onAddSeries() {
    this._mode = "Add";
    this._seriesToEdit = <EmployeeUnderwritingSeriesModel>{};
    this._selectedSeries = undefined;
    this._seriesToEdit.seriesId = "";
    this._seriesToEdit.allowDecision = false;

    if (this.series.length > 0) {
      this._seriesToEdit.employeeId = this.series[0].employeeId;
    }

    await this.loadDropDowns();

    this._displayDialog = true;
  }

  public async onEditSeries(data) {
    this._mode = "Edit";
    this._seriesToEdit = data.rowData;
    await this.loadDropDowns();
    this._selectedSeries = this._series.find(
      (series) => series.seriesId === this._seriesToEdit.seriesId
    );
    this._displayDialog = true;
  }

  public onDeleteSeries(data) {
    this._confirmService.confirm({
      message: "Are you sure that you want to remove this series?",
      header: "Confirmation",
      icon: "pi pi-exclamation-triangle",
      accept: () => {
        this.series = this.series.filter((obj) => obj !== data.rowData);
      },
    });
  }

  onGridReady(params) {
    params.api.sizeColumnsToFit(); // size grid to take up all availibe realestate
    this._gridApi = params.api;
  }

  seriesUpdateCompleted() {
    this._displayDialog = false;
    this._seriesToEdit.seriesId = this._selectedSeries.seriesId;
    this._seriesToEdit.seriesName = this._selectedSeries.seriesName;

    if (this._mode === "Add") {
      this._gridApi.updateRowData({ add: [this._seriesToEdit] });
      this.series.push(this._seriesToEdit);
    } else {
      var row = this.series.findIndex(
        (series) => series.seriesId === this._seriesToEdit.seriesId
      );

      if (row >= 0) {
        var rowNode = this._gridApi.getDisplayedRowAtIndex(row);
        rowNode.setDataValue("seriesName", this._seriesToEdit.seriesName);
        rowNode.setDataValue("allowDecision", this._seriesToEdit.allowDecision);
      }
    }
  }

  async loadDropDowns() {
    if (this._series.length == 0) {
      this._series = await this._uWSeriesService.getAllUnderwritingSeries();
    }
  }
}
