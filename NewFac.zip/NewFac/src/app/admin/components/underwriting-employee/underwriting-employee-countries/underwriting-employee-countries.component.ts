import { Component, OnInit, Input } from "@angular/core";
import { EmployeeUnderwritingCountryModel } from "@models/CRM//employeeUnderwritingCountryModel";
import { GridOptions, ColDef } from "ag-grid-community";
import { ConfirmationService } from "primeng/api";
import { AdminService } from "@admin/service/admin.service";
import { ImageButtonCellComponent } from "@shared/components/grid";
import { CodeModel } from "@models/Common/codeModel";
import { LanguageTranslationService } from "@shared/localization/language-translation.service";

@Component({
  selector: "underwriting-employee-countries",
  templateUrl: "./underwriting-employee-countries.component.html",
  styleUrls: ["./underwriting-employee-countries.component.css"],
})
export class UnderwritingEmployeeCountriesComponent implements OnInit {
  @Input() countries: Array<EmployeeUnderwritingCountryModel>;
  @Input() readOnly: boolean;

  public gridOptions: GridOptions;
  public columnDefs: Array<ColDef>;
  public _displayDialog: boolean;
  public _countryToEdit: EmployeeUnderwritingCountryModel;
  public _countries: Array<CodeModel>;
  public _selectedCountry: CodeModel;
  public _currencies: Array<CodeModel>;
  public _selectedCurrency: CodeModel;
  private _mode: string;
  private _gridApi: any;

  //TODO: Add Global Formatter
  private formatter;

  constructor(
    private _confirmService: ConfirmationService,
    private _adminService: AdminService,
    private _languageTranslationService: LanguageTranslationService
  ) {
    this.gridOptions = {
      defaultColDef: {
        sortable: true,
        resizable: false,
      },
      pagination: false,
      rowHeight: 48,
      headerHeight: 60,
    };
    this._displayDialog = false;
    this._countries = new Array<CodeModel>();
    this._currencies = new Array<CodeModel>();
    this._countryToEdit = <EmployeeUnderwritingCountryModel>{}; //intialize so page does not crash with null values
  }

  ngOnInit() {
    this.formatter = new Intl.NumberFormat(
      this._languageTranslationService.languageParameters.countryCode,
      {
        style: "currency",
        currency: this._languageTranslationService.languageParameters
          .currencyFormat,
        minimumFractionDigits: 2,
      }
    );
    this.columnDefs = this.createColumnDefs();
  }

  createColumnDefs() {
    return [
      { headerName: "Country", field: "countryName" },
      { headerName: "Currency", field: "currencyName" },
      {
        headerName: "View Amount",
        cellRenderer: (params) =>
          this.formatter.format(params.data.minimumViewAmount) +
          "<br/>" +
          this.formatter.format(params.data.maximumViewAmount),
      },
      {
        headerName: "CI View Amount",
        cellRenderer: (params) =>
          this.formatter.format(params.data.criticalIllnessMinViewAmount) +
          "<br/>" +
          this.formatter.format(params.data.criticalIllnessMaxViewAmount),
      },
      {
        headerName: "DI View Amount",
        cellRenderer: (params) =>
          this.formatter.format(params.data.disabilityMinViewAmount) +
          "<br/>" +
          this.formatter.format(params.data.disabilityMaxViewAmount),
      },
      {
        headerName: "LTC View Amount",
        cellRenderer: (params) =>
          this.formatter.format(params.data.ltcMinViewAmount) +
          "<br/>" +
          this.formatter.format(params.data.ltcMaxViewAmount),
      },
      {
        headerName: "Max Decision Amount",
        cellRenderer: (params) =>
          this.formatter.format(params.data.maximumDecisionAmount),
      },
      {
        headerName: "CI Max Decision Amount",
        cellRenderer: (params) =>
          this.formatter.format(params.data.criticalIllnessMaxDecisionAmount),
      },
      {
        headerName: "DI Max Decision Amount",
        cellRenderer: (params) =>
          this.formatter.format(params.data.disabilityMaxDecisionAmount),
      },
      {
        headerName: "LTC Max Decision Amount",
        cellRenderer: (params) =>
          this.formatter.format(params.data.ltcMaxDecisionAmount),
      },
      {
        headerName: "Allow High Dollar Cases",
        field: "allowHighDollarCases",
        valueFormatter: (data) => (data.value ? "Yes" : "No"),
      },
      {
        headerName: "Allow Joint Cases",
        field: "allowJointCases",
        valueFormatter: (data) => (data.value ? "Yes" : "No"),
      },
      {
        headerName: "Allow Previous Cases",
        field: "allowPreviousCases",
        valueFormatter: (data) => (data.value ? "Yes" : "No"),
      },
      {
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onEditCountry.bind(this),
          icon: "pi-pencil",
        },
      },
      {
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onDeleteCountry.bind(this),
          icon: "pi-times",
        },
      },
    ];
  }

  async onAddCountry() {
    this._mode = "Add";
    this._selectedCountry = undefined; // clear out any previous selected countries
    this._selectedCurrency = undefined; // clear out any previos selected currencies
    this.defaultCountryModel();
    this._displayDialog = true;
    await this.loadDropdowns();
  }

  async onEditCountry(data) {
    this._mode = "Edit";
    await this.loadDropdowns();
    this._countryToEdit = data.rowData;
    this._selectedCountry = this._countries.find(
      (country) => country.codeId === this._countryToEdit.countryCodeId
    );
    this._selectedCurrency = this._currencies.find(
      (currency) => currency.codeId === this._countryToEdit.currencyCodeId
    );
    this._displayDialog = true;
  }

  async loadDropdowns() {
    if (this._countries.length == 0) {
      this._countries = await this._adminService.getCountries();
    }

    if (this._currencies.length == 0) {
      this._currencies = await this._adminService.getCurrencies();
    }
  }
  onDeleteCountry(data) {
    this._confirmService.confirm({
      message: "Are you sure that you want to remove this country?",
      header: "Confirmation",
      icon: "pi pi-exclamation-triangle",
      accept: () => {
        this.countries = this.countries.filter((obj) => obj !== data.rowData);
      },
    });
  }

  onGridReady(params) {
    params.api.sizeColumnsToFit(); // size grid to take up all availibe realestate
    this._gridApi = params.api;
  }

  countryUpdateCompleted() {
    this._displayDialog = false;

    this._countryToEdit.currencyName = this._selectedCurrency.codeName;
    this._countryToEdit.currencyCodeId = this._selectedCurrency.codeId;
    this._countryToEdit.countryName = this._selectedCountry.codeName;
    this._countryToEdit.countryCodeId = this._selectedCountry.codeId;

    if (this._mode === "Add") {
      this._gridApi.updateRowData({ add: [this._countryToEdit] });
      this.countries.push(this._countryToEdit);
    } else {
      var row = this.countries.findIndex(
        (country) => country.countryCodeId === this._countryToEdit.countryCodeId
      );

      if (row >= 0) {
        this.countries[row] = this._countryToEdit;
        var rowNode = this._gridApi.getDisplayedRowAtIndex(row);
        this._gridApi.setRowData(this.countries);
        rowNode.setDataValue("countryName", this._selectedCountry.codeName);
        rowNode.setDataValue("currencyName", this._selectedCurrency.codeName);
      }
    }
  }
  defaultCountryModel() {
    this._countryToEdit = <EmployeeUnderwritingCountryModel>{};
    this._countryToEdit.allowHighDollarCases = false;
    this._countryToEdit.allowJointCases = false;
    this._countryToEdit.allowPreviousCases = false;
    this._countryToEdit.maximumViewAmount = 0;
    this._countryToEdit.criticalIllnessMaxViewAmount = 0;
    this._countryToEdit.disabilityMaxViewAmount = 0;
    this._countryToEdit.maximumDecisionAmount = 0;
    this._countryToEdit.criticalIllnessMaxDecisionAmount = 0;
    this._countryToEdit.disabilityMaxDecisionAmount = 0;
    this._countryToEdit.ltcmaxViewAmount = 0;
    this._countryToEdit.ltcmaxDecisionAmount = 0;
    this._countryToEdit.minimumViewAmount = 0;
    this._countryToEdit.criticalIllnessMinViewAmount = 0;
    this._countryToEdit.disabilityMinViewAmount = 0;
    this._countryToEdit.ltcminViewAmount = 0;
  }
}
