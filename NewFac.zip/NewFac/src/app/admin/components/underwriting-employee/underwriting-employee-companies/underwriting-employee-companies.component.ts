import { Component, OnInit, Input } from '@angular/core';
import { CompanyModel } from '@models/companyModel';

@Component({
    selector: 'underwriting-employee-companies',
    templateUrl: './underwriting-employee-companies.component.html',
    styleUrls: ['./underwriting-employee-companies.component.css']
})
export class UnderwritingEmployeeCompaniesComponent implements OnInit {
    private _draggedCompany: CompanyModel;

    @Input() companies: Array<CompanyModel>;
    @Input() companiesExcluded: Array<CompanyModel>;
    @Input() readOnly: boolean;
    constructor() { }

    ngOnInit() {
    }
    companiesDragStart(event, company: CompanyModel) {
        this._draggedCompany = company;
    }

    dropCompanies(event) {
        if (this._draggedCompany) {
            this.companiesExcluded = this.companiesExcluded.filter(obj => obj !== this._draggedCompany);
            this.companies.push(this._draggedCompany);
            this._draggedCompany = null;
        }
    }

    companiesDragEnd(event) {
        this._draggedCompany = null;
    }

    companiesDragExcludedStart(event, company: CompanyModel) {
        this._draggedCompany = company;
    }

    dropCompaniesExcluded(event) {
        if (this._draggedCompany) {
            this.companies = this.companies.filter(obj => obj !== this._draggedCompany);
            this.companiesExcluded.push(this._draggedCompany);
            this._draggedCompany = null;
        }
    }

    companiesDraggExcludedEnd(event) {
        this._draggedCompany = null;
    }
}
