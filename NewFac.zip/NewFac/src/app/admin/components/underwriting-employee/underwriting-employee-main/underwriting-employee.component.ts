import { Component, OnInit, ViewEncapsulation, ViewChild } from "@angular/core";
import { ActivatedRoute, ParamMap } from "@angular/router";
import { EmployeeUnderwritingModel } from "@models/CRM//employeeUnderwritingModel";
import { AdminService } from "@admin/service/admin.service";
import { EmployeeModel } from "@models/CRM/employeeModel";
import {
  UnderwritingEmployeeLanguagesComponent,
  UnderwritingEmployeeCountriesComponent,
  UnderwritingEmployeeSeriesComponent,
  UnderwritingEmployeeCompaniesComponent,
} from "@admin/components/index";
import { MessageService } from "primeng/api";
import { User } from "@models/Auth/user";
import { SiteConstants } from "@models/Constants/site-constants";
import { LocalStorageService } from "@shared/services/localStorage-service";
import { TranslateService } from "@ngx-translate/core";

@Component({
  encapsulation: ViewEncapsulation.None,
  selector: "app-underwriting-employee",
  templateUrl: "./underwriting-employee.component.html",
  styleUrls: ["./underwriting-employee.component.css"],
})
export class UnderwritingEmployeeComponent implements OnInit {
  @ViewChild(UnderwritingEmployeeLanguagesComponent, { static: false })
  languages;
  @ViewChild(UnderwritingEmployeeCompaniesComponent, { static: false })
  companies;
  @ViewChild(UnderwritingEmployeeSeriesComponent, { static: false }) series;
  @ViewChild(UnderwritingEmployeeCountriesComponent, { static: false })
  countries;

  public _employee: EmployeeUnderwritingModel;
  public _isReadOnly: boolean;

  constructor(
    private _adminService: AdminService,
    private _route: ActivatedRoute,
    private _messageService: MessageService,
    private lStorage: LocalStorageService,
    private translate: TranslateService
  ) {
    // initialize employee below to empty to we do not get errors on page load
    this._employee = <EmployeeUnderwritingModel>{};
    this._employee.employee = <EmployeeModel>{};
  }

  async ngOnInit() {
    let id = this._route.snapshot.paramMap.get("id");
    let readOnly = this._route.snapshot.paramMap.get("readOnly");

    this._isReadOnly = readOnly === "1";
    this._employee = await this._adminService.getUwEmploye(id, readOnly);
  }

  async saveForm($event) {
    var currentUser: User = JSON.parse(
      this.lStorage.getValue(SiteConstants.UserToken)
    );
    this._employee.languagesUsed = this.languages.languagesUsed;
    this._employee.employeeUnderwritingSeries = this.series.series;
    this._employee.companiesExcluded = this.companies.companiesExcluded;
    this._employee.employeeUnderwritingCountry = this.countries.countries;
    this._employee.updateUserDomainName = currentUser.username;
    await this._adminService.saveEmployee(this._employee);
    this._messageService.add({
      severity: "success",
      summary: this.translate.instant("admin.uwEmployee.main.summaryHeader"),
      detail: this.translate.instant("admin.uwEmployee.main.detailMessage"),
    });
  }
}
