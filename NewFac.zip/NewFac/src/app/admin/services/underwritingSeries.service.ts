import { Injectable } from "@angular/core";
import { HttpService } from "@shared/services/http-service.service";
import { AppSettingsService } from "@shared/services/app-settings.service";
import { serviceBase } from "@shared/services/servicebase";
import { UnderwritingSeriesModel } from "@models/CRM/underwritingSeriesModel";

@Injectable({
  providedIn: "root"
})
export class UnderwritingSeriesService extends serviceBase {
  private _underwritingSeriesUrl;

  constructor(
    private httpService: HttpService,
    private appSettingService: AppSettingsService
  ) {
    super(httpService, appSettingService);
    this._underwritingSeriesUrl = `${this._apiUrl}/UnderwritingSeries`;
  }

  public async getAllUnderwritingSeries() {
    return await this._httpService.getData<Array<UnderwritingSeriesModel>>(
      `${this._underwritingSeriesUrl}/GetAllUnderwritingSeries`
    );
  }

  public async getUnderwritingSeriesById(seriesId: string) {
    return await this._httpService.getData<UnderwritingSeriesModel>(
      `${this._underwritingSeriesUrl}/GetUnderwritingSeriesById/${seriesId}`
    );
  }

  public async saveSeries(model: UnderwritingSeriesModel) {
    return await this._httpService.postData<UnderwritingSeriesModel>(
      `${this._underwritingSeriesUrl}/SaveUnderwritingSeries`,
      model
    );
  }
}
