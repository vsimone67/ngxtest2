import { Injectable } from "@angular/core";
import { HttpService } from "@shared/service/http-service.service";
import { AppSettingsService } from "@shared/service/app-settings.service";
import { EmployeeUnderwritingModel } from "@models/CRM//employeeUnderwritingModel";
import { UnderwritingSeriesModel } from "@models/CRM/underwritingSeriesModel";
import { CodeModel } from "@models/Common//codeModel";
import { ImpairmentImpairmentCodeModel } from "@models/Impairment/impairmentImpairmentCodeModel";
import { ImpairmentModel } from "@models/Impairment/impairmentModel";
import { PagedListModel } from "@models/paged-list.model";

@Injectable({
  providedIn: "root",
})
export class AdminService {
  private _apiUrl: string;
  private _employeeUwUrl;
  private _employeeSeriesUrl;
  private _facImparementUrl;

  constructor(
    private _httpService: HttpService,
    private _appSettingsService: AppSettingsService
  ) {
    this._apiUrl = this._appSettingsService.GetValue("apiUrl"); //TODO: Add to siteconstants
    this._employeeUwUrl = `${this._apiUrl}/UnderwritingEmployee`;
    this._employeeSeriesUrl = `${this._apiUrl}/UnderwritingSeries`;
    this._facImparementUrl = `${this._apiUrl}/admin/Impairment`;
  }

  async getAllUwEmployees(currentPage: number, pageSize: number) {
    return await this._httpService.getData<
      PagedListModel<EmployeeUnderwritingModel>
    >(`${this._employeeUwUrl}/GetAllUWEmployees/${currentPage}/${pageSize}`);
  }
  async getUwEmploye(id: string, isReadOnly: string) {
    return await this._httpService.getData<EmployeeUnderwritingModel>(
      `${this._employeeUwUrl}/GetEmployeeInfo/${id}/${isReadOnly}`
    );
  }

  async getSeries() {
    return await this._httpService.getData<Array<UnderwritingSeriesModel>>(
      `${this._employeeSeriesUrl}/GetSeries`
    );
  }

  async saveEmployee(model: EmployeeUnderwritingModel) {
    return await this._httpService.postData<EmployeeUnderwritingModel>(
      `${this._employeeUwUrl}/SaveUwEmployee`,
      model
    );
  }

  async getCountries() {
    return await this._httpService.getData<Array<CodeModel>>(
      `${this._employeeUwUrl}/GetCountries`
    );
  }

  async getCurrencies() {
    return await this._httpService.getData<Array<CodeModel>>(
      `${this._employeeUwUrl}/GetCurrencies`
    );
  }

  async getFacImpiarements() {
    return await this._httpService.getData<
      Array<ImpairmentImpairmentCodeModel>
    >(`${this._facImparementUrl}/`);
  }

  async getFacImpairmentCodes() {
    return await this._httpService.getData<Array<ImpairmentModel>>(
      `${this._facImparementUrl}/GetImpairmentImpairmentCodes`
    );
  }

  async addImpairement(model: ImpairmentImpairmentCodeModel) {
    return await this._httpService.postData<ImpairmentImpairmentCodeModel>(
      `${this._facImparementUrl}/AddImpairementCode`,
      model
    );
  }

  async updateImpairement(model: ImpairmentImpairmentCodeModel) {
    return await this._httpService.postData<ImpairmentImpairmentCodeModel>(
      `${this._facImparementUrl}/UpdateImpairmentCode`,
      model
    );
  }

  async deleteImpairement(model: ImpairmentImpairmentCodeModel) {
    return await this._httpService.postData<ImpairmentImpairmentCodeModel>(
      `${this._facImparementUrl}/DeleteImpairmentCode`,
      model
    );
  }
}
