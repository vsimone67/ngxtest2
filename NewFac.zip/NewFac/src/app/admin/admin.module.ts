import { NgModule } from "@angular/core";
import { UnderwritingEmployeeListComponent } from "@admin/components/underwriting-employee-list/underwriting-employee-list.component";
import { SharedModule } from "@shared/shared.module";
import { AdminService } from "@admin/service/admin.service";
import { AgGridModule } from "ag-grid-angular";
import {
  ButtonCellComponent,
  ImageButtonCellComponent,
} from "@shared/components/grid";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";

import { AdminRoutingModule } from "@admin/admin-routing";
import {
  UnderwritingEmployeeComponent,
  UnderwritingEmployeeSeriesComponent,
  UnderwritingEmployeeLanguagesComponent,
  UnderwritingEmployeeCountriesComponent,
} from "@admin/components/index";
import { UnderwritingEmployeeCompaniesComponent } from "@admin/components/underwriting-employee/underwriting-employee-companies/underwriting-employee-companies.component";
import { FacImparementComponent } from "./components/fac-imparement/fac-imparement.component";
import { ImpairementComponent } from "./components/fac-imparement/ImpairementComponent";
import { UnderwritingSeriesListComponent } from "./components/underwriting-series-list/underwriting-series-list.component";
import { UnderwritingSeriesService } from "@admin/services/underwritingSeries.service";
import { NumberRangeValidatorDirective } from "@validators/numberrange.validator";
import {
  UnderwritingSeriesMainComponent,
  UnderwritingSeriesCountryComponent,
  UnderwritingSeriesLanguageComponent,
} from "@admin/components/index";

@NgModule({
  declarations: [
    UnderwritingEmployeeListComponent,
    ButtonCellComponent,
    ImageButtonCellComponent,
    UnderwritingEmployeeComponent,
    UnderwritingEmployeeSeriesComponent,
    UnderwritingEmployeeLanguagesComponent,
    UnderwritingEmployeeCountriesComponent,
    UnderwritingEmployeeCompaniesComponent,
    FacImparementComponent,
    // ImpairementComponent,
    UnderwritingSeriesListComponent,
    NumberRangeValidatorDirective,
    UnderwritingSeriesMainComponent,
    UnderwritingSeriesCountryComponent,
    UnderwritingSeriesLanguageComponent,
  ],
  imports: [
    SharedModule,
    AgGridModule.withComponents([
      ButtonCellComponent,
      ImageButtonCellComponent,
    ]),
    AdminRoutingModule,
    ReactiveFormsModule,
  ],
  exports: [AdminRoutingModule],
  providers: [AdminService, UnderwritingSeriesService],
  entryComponents: [ImpairementComponent],
})
export class AdminModule {}
