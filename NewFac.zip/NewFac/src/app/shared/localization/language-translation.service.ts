import { ILocalization } from "./ILocalization";
import { TranslateService } from "@ngx-translate/core";
import { LocalStorageService } from "@shared/services/localStorage-service";
import {
  SiteConstants,
  supportedLanguages,
} from "@models/Constants/site-constants";
import { Injectable } from "@angular/core";

// To add a new language to the app
// 1. Add new language to supportedLanguages constant in site-constants.ts (located in models/constants)
// 2. Create a new json file with the language you want to add (copy all contexts from en.json as a starting poiont)

@Injectable({
  providedIn: "root",
})
export class LanguageTranslationService {
  public languageParameters: ILocalization = <ILocalization>{};
  constructor(
    private translate: TranslateService,
    private lStorage: LocalStorageService
  ) {}

  async loadTraslationFile() {
    var languages = [];

    // get the constant supportedLocales (holds all languares we are supporting) and iterate through it and pass the values to the language tranlation service
    supportedLanguages.forEach((language) => languages.push(language.locale));

    this.translate.addLangs(languages); // tell the traslate service what languages we are going to translate

    var language = this.lStorage.getValue(SiteConstants.savedLocale) || "en"; // get the stored language the user has selected, if none, then default to english

    this.setLangage(language);
  }
  async loadNewLanguage(language: string) {
    this.lStorage.setValue(SiteConstants.savedLocale, language);

    this.setLangage(language);
  }

  private setLangage(language: string) {
    this.translate.use(language);
    this.translate.get("languageParameters.dayNames").subscribe(() => {
      this.loadParameters();
    });
  }

  public loadParameters() {
    this.languageParameters.calendarFormat = {
      firstDayOfWeek: 1,
      dayNames: this.translate.instant("languageParameters.calendar.dayNames"),
      dayNamesShort: this.translate.instant(
        "languageParameters.calendar.dayNamesShort"
      ),
      dayNamesMin: this.translate.instant(
        "languageParameters.calendar.dayNamesMin"
      ),
      monthNames: this.translate.instant(
        "languageParameters.calendar.monthNames"
      ),
      monthNamesShort: this.translate.instant(
        "languageParameters.calendar.monthNamesShort"
      ),
      today: this.translate.instant("languageParameters.calendar.today"),
      clear: this.translate.instant("languageParameters.calendar.clear"),
    };

    this.languageParameters.currencyFormat = this.translate.instant(
      "languageParameters.currencyFormat"
    );
    this.languageParameters.dateFormatCalendar = this.translate.instant(
      "languageParameters.dateFormatCalendar"
    );
    this.languageParameters.dateFormatGrid = this.translate.instant(
      "languageParameters.dateFormatGrid"
    );
    this.languageParameters.countryCode = this.translate.instant(
      "languageParameters.countryCode"
    );
  }
}
