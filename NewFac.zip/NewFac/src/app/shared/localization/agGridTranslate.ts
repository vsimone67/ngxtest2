import { AppModule } from "src/app/app.module";
import { TranslateService } from "@ngx-translate/core";

export function agGridTranslateGridItems(key, defaultValue) {
  var gridKey = "agGrid." + key; // the secton where the translation file

  var injector = AppModule.injector.get(TranslateService); //use global injector
  var value = injector.instant(gridKey); //translate grid components

  return value === gridKey ? defaultValue : value;
}
