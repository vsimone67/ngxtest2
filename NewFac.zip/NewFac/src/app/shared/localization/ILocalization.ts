import { ICalendar } from "./ICalendar";

export interface ILocalization {
  dateFormatCalendar: string;
  dateFormatGrid: string;
  currencyFormat: string;
  calendarFormat: ICalendar;
  countryCode: string;
}
