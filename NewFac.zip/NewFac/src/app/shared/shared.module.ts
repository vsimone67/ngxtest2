import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { HttpClientModule, HttpClient } from "@angular/common/http";
import { BreadcrumbModule } from "primeng/breadcrumb";
import { BreadcrumbComponent } from "./components/breadcrumb/breadcrumb.component";
import { MenuModule } from "primeng/menu";
import { ButtonModule } from "primeng/button";
import { ToastComponent } from "./components/toast/toast.component";
import { ToastModule } from "primeng/toast";
import { MessageService } from "primeng/api";
import { MessagesModule } from "primeng/messages";
import { MessageModule } from "primeng/message";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { AppSettingsService } from "@shared/services/app-settings.service";
import { HttpService } from "@shared/services/http-service.service";
import { EventService } from "@shared/services/event.service";
import { InputTextModule } from "primeng/inputtext";
import { CheckboxModule } from "primeng/checkbox";
import { ListboxModule } from "primeng/listbox";
import { DragDropModule } from "primeng/dragdrop";
import { ConfirmDialogModule } from "primeng/confirmdialog";
import { ConfirmationService } from "primeng/api";
import { DialogModule } from "primeng/dialog";
import { DropdownModule } from "primeng/dropdown";
import { RadioButtonModule } from "primeng/radiobutton";
import { InputSwitchModule } from "primeng/inputswitch";
import { TabViewModule } from "primeng/tabview";
import { TableModule } from "primeng/table";
import { ProgressSpinnerModule } from "primeng/progressspinner";
import { DocumentListComponent } from "./components/document-list/document-list.component";
import { AgGridModule } from "ag-grid-angular";
import { CalendarModule } from "primeng/calendar";
import { InputTextareaModule } from "primeng/inputtextarea";
import { FileUploadModule } from "primeng/fileupload";
import {
  ButtonCellComponent,
  ImageButtonCellComponent,
} from "./components/grid";
import { DocumentService } from "./services/document.service";
import { CodeService } from "./services/code.service";
import { ReactiveFormsModule } from "@angular/forms";

import {
  TranslateLoader,
  TranslateModule,
  TranslateService,
} from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";
import { LocalStorageService } from "./services/localStorage-service";
import { LanguageTranslationService } from "./localization/language-translation.service";
import { PaginatorModule } from "primeng/paginator";

@NgModule({
  declarations: [BreadcrumbComponent, ToastComponent, DocumentListComponent],
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    BreadcrumbModule,
    MenuModule,
    ButtonModule,
    ToastModule,
    MessagesModule,
    MessageModule,
    BrowserAnimationsModule,
    InputTextModule,
    CheckboxModule,
    ListboxModule,
    DragDropModule,
    ConfirmDialogModule,
    DialogModule,
    DropdownModule,
    RadioButtonModule,
    InputSwitchModule,
    TabViewModule,
    TableModule,
    ProgressSpinnerModule,
    CalendarModule,
    InputTextareaModule,
    FileUploadModule,
    ReactiveFormsModule,
    PaginatorModule,
    AgGridModule.withComponents([
      ButtonCellComponent,
      ImageButtonCellComponent,
    ]),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
    }),
  ],
  exports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    BreadcrumbComponent,
    MenuModule,
    ButtonModule,
    ToastComponent,
    ToastModule,
    MessagesModule,
    MessageModule,
    BrowserAnimationsModule,
    InputTextModule,
    CheckboxModule,
    ListboxModule,
    DragDropModule,
    ConfirmDialogModule,
    DialogModule,
    DropdownModule,
    RadioButtonModule,
    InputSwitchModule,
    TabViewModule,
    TableModule,
    ProgressSpinnerModule,
    DocumentListComponent,
    CalendarModule,
    InputTextareaModule,
    FileUploadModule,
    ReactiveFormsModule,
    TranslateModule,
    PaginatorModule,
  ],
  providers: [
    MessageService,
    AppSettingsService,
    HttpService,
    EventService,
    ConfirmationService,
    DocumentService,
    CodeService,
    TranslateService,
    LocalStorageService,
    LanguageTranslationService,
  ],
})
export class SharedModule {}

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
