import {
  Component,
  OnInit,
  Input,
  SimpleChanges,
  ViewChild,
} from "@angular/core";
import { ColDef, GridOptions } from "ag-grid-community";
import { DocumentListModel } from "@models/Common//document-list.model";
import { DocumentService } from "@shared/services/document.service";
import { ImageButtonCellComponent } from "../grid";
import { User } from "@models/Auth/user";
import { SiteConstants } from "@models/Constants/site-constants";
import { HttpEventType } from "@angular/common/http";
import { ConfirmationService } from "primeng/api";

import { CodeModel } from "@models/Common//codeModel";
import { CodeService } from "@shared/services/code.service";
import { FileUpload } from "primeng/fileupload";
import { FormBuilder, FormGroup } from "@angular/forms";
import * as moment from "moment";
import { TranslateService } from "@ngx-translate/core";
import { LocalStorageService } from "@shared/services/localStorage-service";
import { ILocalization } from "@shared/localization/ILocalization";
import { LanguageTranslationService } from "@shared/localization/language-translation.service";
import { agGridTranslateGridItems } from "@shared/localization/agGridTranslate";

@Component({
  selector: "document-list",
  templateUrl: "./document-list.component.html",
  styleUrls: ["./document-list.component.css"],
})
export class DocumentListComponent implements OnInit {
  @Input() GroupId: string;
  @ViewChild("fileInput", { static: false }) fileInput: FileUpload;

  public columnDefs: Array<ColDef>;
  public gridOptions: GridOptions;
  private _gridApi: any;
  public _displayDialog: boolean;
  public _documents: Array<DocumentListModel>;
  public _documentToUpload: DocumentListModel;
  public _documentCategories: Array<CodeModel>;
  public _selectedDocumnetCategory: CodeModel;
  public _mode: string;
  public _payload: FormGroup;
  public _languageParameters: ILocalization;

  constructor(
    public _docService: DocumentService,
    public _codeService: CodeService,
    public _confirmService: ConfirmationService,
    public _formBuilder: FormBuilder,
    public translate: TranslateService,
    public lStorage: LocalStorageService,
    public _languageTranslationService: LanguageTranslationService
  ) {
    this.gridOptions = {
      defaultColDef: {
        sortable: true,
        resizable: false,
      },
      pagination: false,
      localeTextFunc: agGridTranslateGridItems,
    };

    this._displayDialog = false;
    this._documentToUpload = <DocumentListModel>{};
    this._documentCategories = new Array<CodeModel>();
  }

  ngOnInit() {
    this.createColumnDefs();

    this._payload = this._formBuilder.group({
      profile: [""],
    });
  }

  createColumnDefs() {
    // Ensure all translations are loaded (translate returns an observable)
    this.translate.get("common.documentList.grid").subscribe(() => {
      this.columnDefs = [
        {
          headerName: this.translate.instant(
            "common.documentList.grid.dateHeader"
          ),
          field: "documentScanDate",
          width: 100,
          valueFormatter: (data) =>
            (data.value &&
              moment(data.value).format(
                this._languageTranslationService.languageParameters
                  .dateFormatGrid
              )) ||
            "",
        },
        {
          headerName: this.translate.instant(
            "common.documentList.grid.createdByHeader"
          ),
          field: "createdByName",
          width: 135,
        },
        {
          headerName: this.translate.instant(
            "common.documentList.grid.categoryHeader"
          ),
          field: "documentCategoryName",
          width: 145,
        },
        {
          headerName: this.translate.instant(
            "common.documentList.grid.nameHeader"
          ),
          field: "documentName",
        },
        {
          headerName: "",
          cellRendererFramework: ImageButtonCellComponent,
          cellRendererParams: {
            onClick: this.onViewDocument.bind(this),
            icon: "pi-file",
          },
          width: 45,
        },
        {
          headerName: "",
          cellRendererFramework: ImageButtonCellComponent,
          cellRendererParams: {
            onClick: this.onEditDocument.bind(this),
            icon: "pi-pencil",
          },
          width: 45,
        },
        {
          headerName: "",
          cellRendererFramework: ImageButtonCellComponent,
          cellRendererParams: {
            onClick: this.onDeleteDocument.bind(this),
            icon: "pi-times",
          },
          width: 45,
        },
      ];
    });
  }

  async loadDropdowns() {
    if (this._documentCategories.length === 0) {
      this._documentCategories = await this._codeService.getCodesByCategoryId(
        "231150C3-8A62-412F-B6C8-61FDC924278D"
      );
    }
  }

  onGridReady(params) {
    params.api.sizeColumnsToFit(); // size grid to take up all availibe realestate
    this._gridApi = params.api;
  }

  async ngOnChanges(changes: SimpleChanges) {
    this._documents = await this._docService.getDocumentByGroup(this.GroupId);
  }

  onAddDocument() {
    this._mode = "Add";
    this.loadDropdowns();
    this._documentToUpload = <DocumentListModel>{};
    this._displayDialog = true;
  }

  async onEditDocument(data) {
    this._mode = "Edit";
    this.loadDropdowns();
    this._documentToUpload = data.rowData;
    this._selectedDocumnetCategory = this._documentCategories.find(
      (category) =>
        category.codeId === this._documentToUpload.documentCategoryId
    );
    this._displayDialog = true;
  }
  async onDeleteDocument(data) {
    this._confirmService.confirm({
      message: this.translate.instant(
        "common.documentList.dialog.warningMessage.message"
      ),
      header: this.translate.instant(
        "common.documentList.dialog.warningMessage.header"
      ),
      icon: "pi pi-exclamation-triangle",
      acceptLabel: this.translate.instant(
        "common.documentList.dialog.warningMessage.acceptLabel"
      ),
      rejectLabel: this.translate.instant(
        "common.documentList.dialog.warningMessage.rejectLabel"
      ),
      accept: () => {},
    });
  }

  async onViewDocument(data) {
    var currentUser: User = JSON.parse(
      this.lStorage.getValue(SiteConstants.UserToken)
    );

    this._docService
      .downloadFile(data.rowData.documentURL, currentUser.userId)
      .subscribe((data) => {
        switch (data.type) {
          case HttpEventType.Response:
            const downloadedFile = new Blob([data.body], {
              type: data.body.type,
            });
            const url = window.URL.createObjectURL(downloadedFile);
            window.open(url);
            break;
        }
      });
  }

  async saveDocument() {
    this._displayDialog = false;

    var currentUser: User = JSON.parse(
      this.lStorage.getValue(SiteConstants.UserToken)
    );
    var fileToUpload = this.fileInput.files[0];

    let input = new FormData();
    input.append("Name", this._documentToUpload.documentName);
    input.append("CodeId", this._selectedDocumnetCategory.codeId);
    input.append("ReceivedDate", this._documentToUpload.documentReceivedDate);
    input.append("Description", this._documentToUpload.documentDescription);
    input.append("UserId", currentUser.userId);
    input.append("file", fileToUpload);

    this._docService.uploadFile1(input).subscribe((res) => {
      console.log(res);
    });
  }
}
