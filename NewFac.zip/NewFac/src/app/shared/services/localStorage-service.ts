import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root",
})
export class LocalStorageService {
  public getValue(key: string): string {
    return localStorage.getItem(key);
  }

  public setValue(key: string, value: string) {
    localStorage.setItem(key, value);
  }

  public getValueObject<T>(key: string) {
    return JSON.parse(this.getValue(key)) as T;
  }

  public removeItem(key: string) {
    localStorage.removeItem(key);
  }
}
