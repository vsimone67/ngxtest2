import { Injectable } from "@angular/core";
import { HttpService } from "./http-service.service";
import { AppSettingsService } from "./app-settings.service";
import { serviceBase } from "./servicebase";
import { DocumentListModel } from "@models/Common//document-list.model";
import { SavedDocumentModel } from "@models/Common//SavedDocumentModel";
import { HttpRequest, HttpEvent } from "@angular/common/http";
import { Observable } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class DocumentService extends serviceBase {
  private _documentUrl;

  constructor(
    private httpService: HttpService,
    private appSettingsService: AppSettingsService
  ) {
    super(httpService, appSettingsService);
    this._documentUrl = `${this._apiUrl}/Document`;
  }

  public async getDocumentByGroup(groupId: string) {
    return await this.getData<Array<DocumentListModel>>(
      `${this._documentUrl}/GetDocumentsByGroup/${groupId}`
    );
  }

  public uploadFile(payload) {
    return this._httpService.uploadfile(
      `${this._documentUrl}/UploadFile/`,
      payload
    );
  }

  public downloadFile(
    docUrl: string,
    userId: string
  ): Observable<HttpEvent<Blob>> {
    return this._httpService.getBlob(
      `${this._documentUrl}/DownloadFile/${docUrl}/${userId}`
    );
  }

  public uploadFile1(payload) {
    return this._httpService.uploadfile(
      `${this._documentUrl}/UploadFile/`,
      payload
    );
  }
  //TODO:  Save document
}
