import { HttpService } from "./http-service.service";
import { AppSettingsService } from "./app-settings.service";

export class serviceBase {
  protected _apiUrl: string;

  constructor(
    protected _httpService: HttpService,
    protected _appSettingsService: AppSettingsService
  ) {
    this._apiUrl = this._appSettingsService.GetValue("apiUrl");
  }

  protected async getData<T>(url: string) {
    return await this._httpService.getData<T>(url);
  }

  protected async postData<T>(url: string, model: T) {
    return await this._httpService.postData<T>(url, model);
  }
}
