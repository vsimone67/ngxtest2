import { Injectable } from "@angular/core";
import { HttpService } from "./http-service.service";
import { AppSettingsService } from "./app-settings.service";
import { serviceBase } from "./servicebase";
import { CodeModel } from "@models/Common//codeModel";

@Injectable({
  providedIn: "root",
})
export class CodeService extends serviceBase {
  private _codeUrl;

  constructor(
    private httpService: HttpService,
    private appSettingsService: AppSettingsService
  ) {
    super(httpService, appSettingsService);
    this._codeUrl = `${this._apiUrl}/Code`;
  }

  async getCodesByCategoryId(categoryId: string) {
    return await this._httpService.getData<Array<CodeModel>>(
      `${this._codeUrl}/GetCategoryById/${categoryId}`
    );
  }
}
