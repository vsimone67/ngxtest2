import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import {
  ProAthletesComponent,
  UnderwriterTasksComponent,
} from "@fac/components/index";

const routes: Routes = [
  {
    path: "proathletes",
    data: { breadcrumb: "Pro Athletes" },
    component: ProAthletesComponent,
  },
  {
    path: "uwtasks",
    data: { breadcrumb: "facultative.underwriterTasks.breadcrumb" },
    component: UnderwriterTasksComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FacultativeRoutingModule {}
