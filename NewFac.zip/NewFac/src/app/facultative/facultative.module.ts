import { NgModule } from "@angular/core";
import { SharedModule } from "@shared/module/shared.module";
import { ProAthletesComponent } from "@fac/components/pro-athletes/pro-athletes.component";
import { FacultativeRoutingModule } from "@fac/module/facultative-routing";
import { SearchComponent } from "./components/search/search.component";
import { IndexDocumentsComponent } from "./components/index-documents/index-documents.component";
import { RecentlyViewedComponent } from "./components/recently-viewed/recently-viewed.component";
import { AlertsComponent } from "@fac/components/facsubmission/alerts/alerts.component";
import { AgGridModule } from "ag-grid-angular";
import { ButtonCellComponent } from "@shared/components/grid/button-cell/button-cell.component";
import { ImageButtonCellComponent } from "@shared/components/grid";
import { UnderwriterTasksComponent } from "./components/underwriter-tasks/underwrite-tasks-main/underwriter-tasks.component";
import { ByTasksComponent } from "./components/underwriter-tasks/by-tasks/by-tasks.component";
import { ByUnderwriterComponent } from "./components/underwriter-tasks/by-underwriter/by-underwriter.component";
import { UwTaskService } from "./services/uw-task.service";
import { FacultativeService } from "./services/facultative.service";

@NgModule({
  declarations: [
    ProAthletesComponent,
    SearchComponent,
    IndexDocumentsComponent,
    RecentlyViewedComponent,
    AlertsComponent,
    UnderwriterTasksComponent,
    ByTasksComponent,
    ByUnderwriterComponent,
  ],
  imports: [
    SharedModule,
    AgGridModule.withComponents([
      ButtonCellComponent,
      ImageButtonCellComponent,
    ]),
    FacultativeRoutingModule,
  ],
  exports: [
    ProAthletesComponent,
    FacultativeRoutingModule,
    SearchComponent,
    IndexDocumentsComponent,
    RecentlyViewedComponent,
    AlertsComponent,
  ],
  providers: [UwTaskService, FacultativeService],
})
export class FacultativeModule {}
