import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'fac-index-documents',
    templateUrl: './index-documents.component.html',
    styleUrls: ['./index-documents.component.css']
})
export class IndexDocumentsComponent implements OnInit {
    constructor() { }

    ngOnInit() {
    }
}
