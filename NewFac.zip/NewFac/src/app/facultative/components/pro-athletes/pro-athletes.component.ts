import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pro-athletes',
  templateUrl: './pro-athletes.component.html',
  styleUrls: ['./pro-athletes.component.css']
})
export class ProAthletesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
