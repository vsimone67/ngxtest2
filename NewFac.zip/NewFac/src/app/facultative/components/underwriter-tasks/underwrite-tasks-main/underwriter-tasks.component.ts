import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'underwriter-tasks',
  templateUrl: './underwriter-tasks.component.html',
  styleUrls: ['./underwriter-tasks.component.css']
})
export class UnderwriterTasksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
