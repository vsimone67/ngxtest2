import { Component, OnInit } from "@angular/core";
import { UwTaskService } from "@fac/services/uw-task.service";
import { UnderwritingTeamsTaskTotalsModel } from "@models/underwritingTeamsTaskTotalsModel";

@Component({
  selector: "by-underwriter",
  templateUrl: "./by-underwriter.component.html",
  styleUrls: ["./by-underwriter.component.css"],
})
export class ByUnderwriterComponent implements OnInit {
  public _teamCols: any[];
  public _uwTaskCols: any[];

  public _uwTeamsTask: Array<UnderwritingTeamsTaskTotalsModel>;

  public _isLoading: boolean;

  constructor(private _uwTaskService: UwTaskService) {
    this._isLoading = false;
  }

  async ngOnInit() {
    this._isLoading = true;

    this._teamCols = [
      { field: "underwriter", header: "Underwriter" },
      { field: "maximumFacCaseCount", header: "Max Count" },
      { field: "newWithin24Hrs", header: "24 Hours" },
      { field: "new24To48", header: "24-48 Hours" },
      { field: "new48Hrspls", header: "48+ Hours" },
      { field: "additionalPapers", header: "Add. Papers" },
      { field: "otherAlertsToday", header: "Other ALerts Assigned" },
      { field: "totalActiveTasks", header: "Total Active Tasks" },
      { field: "outstandingAlerts", header: "Outstadning Alerts to Other" },
      { field: "newAssignedToday", header: "New Assigned Today" },
      { field: "addAssignedToday", header: "Add. Papers Assigned Today" },
      { field: "newCompletedToday", header: "Total New Completed Today" },
      {
        field: "addCompletedToday",
        header: "Total Add Papers Completed Today",
      },
      {
        field: "opinionOnlyDecisionToday",
        header: "Total Opinion Decisions Today",
      },
      {
        field: "opinionOnlyCasesCompletedToday",
        header: "Total Opinion Only Cases Completed Today",
      },
    ];

    this._uwTaskCols = [
      { field: "PrioritizationScore", header: "Score" },
      { field: "generaliFacCessionNumber", header: "Cession" },
      { field: "applicantName", header: "Applicant Name" },
      { field: "companyName", header: "Company Name" },
      { field: "seriesName", header: "Series" },
      { field: "anguageName", header: "Language" },
      { field: "lob", header: "LOB" },
      { field: "benefits", header: "Coverage Type" },
      { field: "issueAmount", header: "Applied Amount" },
      { field: "receivedDate", header: "Recevied Date" },
      { field: "taskAssignedDate", header: "Tasl Assogmed Date" },
      { field: "taskType", header: "Task Type" },
      { field: "alertStatus", header: "Related Alerts" },
      { field: "facAppStatus", header: "Applicaton Status" },
      { field: "facSubStatus", header: "Submission Status" },
    ];

    this._uwTeamsTask = await this._uwTaskService.getUwTeamsTask();
    this._isLoading = false;
  }

  async onRowExpand(event) {
    event.data.underwritertasks = await this._uwTaskService.getTaskByUw(
      event.data.employeeId
    );
  }
}
