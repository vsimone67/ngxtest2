import { Component, OnInit } from "@angular/core";
import { ColDef, GridOptions } from "ag-grid-community";
import { UnderwritingAllTasksModel } from "@models/underwritingAllTasksModel";
import { UwTaskService } from "@fac/services/uw-task.service";
import { _supportsShadowDom } from "@angular/cdk/platform";
import { ImageButtonCellComponent } from "@shared/components/grid";
import * as moment from "moment";
import { EmployeeUnderwritingModel } from "@models/CRM//employeeUnderwritingModel";
import { ReassignTask } from "@models/Facultative/ReassignTask";
import { MessageService } from "primeng/api";
import { AdminService } from "@admin/services/admin.service";
import { PagedListModel } from "@models/paged-list.model";
@Component({
  selector: "by-tasks",
  templateUrl: "./by-tasks.component.html",
  styleUrls: ["./by-tasks.component.css"],
})
export class ByTasksComponent implements OnInit {
  public columnDefs: Array<ColDef>;
  public gridOptions: GridOptions;
  public _gridApi: any;
  public _allTasks: Array<UnderwritingAllTasksModel>;
  public _displayDialog: boolean;
  public _uwList: PagedListModel<EmployeeUnderwritingModel>;
  public _selectedUw: EmployeeUnderwritingModel;
  public _selectedTask: UnderwritingAllTasksModel;

  private formatter = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
  });
  constructor(
    private _uwTaskService: UwTaskService,
    private _adminService: AdminService,
    private _messageService: MessageService
  ) {
    this.gridOptions = {
      defaultColDef: {
        sortable: true,
        resizable: false,
      },
      pagination: false,
    };

    this._displayDialog = false;
    this._uwList = new PagedListModel<EmployeeUnderwritingModel>();
  }

  async ngOnInit() {
    this.columnDefs = this.createColumnDefs();
    this._allTasks = await this._uwTaskService.getTaskByUw(
      "00000000-0000-0000-0000-000000000000"
    );
  }

  createColumnDefs() {
    return [
      { headerName: "Task Assigned To", field: "uwName" },
      { headerName: "Cession", field: "generaliFacCessionNumber" },
      { headerName: "Score", field: "prioritizationScore" },
      { headerName: "Applicant Name", field: "applicantName" },
      { headerName: "Company Name", field: "companyName" },
      { headerName: "Series", field: "seriesName" },
      { headerName: "Language", field: "languageName" },
      { headerName: "LOB", field: "lob" },
      { headerName: "Coverage Type", field: "benefits" },
      {
        headerName: "Applied Amount",
        cellRenderer: (params) =>
          this.formatter.format(params.data.issueAmount),
      },
      {
        headerName: "Recevied Date",
        field: "receivedDate",
        valueFormatter: (data) => (data && moment(data).format("L")) || "",
      },
      {
        headerName: "Task Assigned Date",
        field: "taskAssignedDate",
        valueFormatter: (data) => (data && moment(data).format("L")) || "",
      },
      { headerName: "Task Type", field: "taskType" },
      { headerName: "Related Alerts", field: "alertStatus" },
      { headerName: "Application Status", field: "facAppStatus" },
      { headerName: "Submission Status", field: "facSubStatus" },

      {
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onReassignUw.bind(this),
          icon: "pi-pencil",
        },
      },
    ];
  }

  onGridReady(params) {
    params.api.sizeColumnsToFit(); // size grid to take up all availibe realestate
    this._gridApi = params.api;
  }

  public async onReassignUw(data) {
    this._selectedTask = data.rowData;
    await this.loadUwEmployees();

    this._displayDialog = true;
  }

  public async reassignUw() {
    this._displayDialog = false;
    let payLoad = <ReassignTask>{};

    payLoad.reassignedUnderwriterId = this._selectedUw.employeeId;
    payLoad.taskId = this._selectedTask.taskId;
    await this._uwTaskService.ReassignTask(payLoad);
    this.displayMessage("Task has been reassigned");
  }

  //TODO: Add Paging here
  private async loadUwEmployees() {
    if (this._uwList.payload.length == 0) {
      this._uwList = await this._adminService.getAllUwEmployees(1, 1);
    }
  }

  private displayMessage(message: string) {
    this._messageService.add({ severity: "success", detail: message });
  }
}
