import { Component, OnInit } from "@angular/core";
import { SubmissionSearchModel } from "@models/SubmissionSearch/submissionSearchModel";
import { FacultativeService } from "@fac/service/facultative.service";

@Component({
  selector: "fac-search",
  templateUrl: "./search.component.html",
  styleUrls: ["./search.component.css"],
})
export class SearchComponent implements OnInit {
  public _searchModel: SubmissionSearchModel;

  constructor(private _facultativeService: FacultativeService) {
    this._searchModel = <SubmissionSearchModel>{};
  }

  ngOnInit() {}

  async onSearch() {}

  clearForm() {}
}
