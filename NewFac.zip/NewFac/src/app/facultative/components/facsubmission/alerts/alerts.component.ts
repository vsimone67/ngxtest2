import {
  Component,
  OnInit,
  Input,
  OnChanges,
  SimpleChanges,
} from "@angular/core";
import { ColDef, GridOptions } from "ag-grid-community";
import { AlertTasksModel } from "@models/Facultative/alertTasksModel";
import { FacultativeService } from "@fac/services/facultative.service";

@Component({
  selector: "alerts",
  templateUrl: "./alerts.component.html",
  styleUrls: ["./alerts.component.css"],
})
export class AlertsComponent implements OnInit, OnChanges {
  @Input() appId: string;
  @Input() employeeId: string;

  public columnDefs: Array<ColDef>;
  public gridOptions: GridOptions;
  private _gridApi: any;
  public _alerts: Array<AlertTasksModel>;

  constructor(private _facService: FacultativeService) {
    this.gridOptions = {
      defaultColDef: {
        sortable: true,
        resizable: false,
      },
      pagination: false,
    };
  }

  ngOnInit() {
    this.columnDefs = this.createColumnDefs();
  }

  createColumnDefs() {
    return [
      { headerName: "Name", field: "assignedToName" },
      { headerName: "Alert Type", field: "alertType" },
      { headerName: "Assigned Date", field: "createDate" },
    ];
  }

  onGridReady(params) {
    params.api.sizeColumnsToFit(); // size grid to take up all availibe realestate
    this._gridApi = params.api;
  }

  async ngOnChanges(changes: SimpleChanges) {
    this._alerts = await this._facService.getAlerts(
      this.appId,
      this.employeeId
    );
  }
}
