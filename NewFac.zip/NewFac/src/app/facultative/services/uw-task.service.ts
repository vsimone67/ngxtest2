import { Injectable } from "@angular/core";
import { serviceBase } from "@shared/services/servicebase";
import { HttpService } from "@shared/services/http-service.service";
import { AppSettingsService } from "@shared/services/app-settings.service";
import { UnderwritingTeamsTaskTotalsModel } from "@models/underwritingTeamsTaskTotalsModel";
import { UnderwritingAllTasksModel } from "@models/underwritingAllTasksModel";
import { ReassignTask } from "@models/Facultative/ReassignTask";

@Injectable({
  providedIn: "root"
})
export class UwTaskService extends serviceBase {
  private _uwTaskUrl;

  constructor(
    private httpService: HttpService,
    private appSettingsService: AppSettingsService
  ) {
    super(httpService, appSettingsService);
    this._uwTaskUrl = `${this._apiUrl}/UnderwriterTasks`;
  }

  public async getUwTeamsTask() {
    return await this.getData<Array<UnderwritingTeamsTaskTotalsModel>>(
      this._uwTaskUrl
    );
  }

  public async getTaskByUw(id: string) {
    return await this.getData<Array<UnderwritingAllTasksModel>>(
      `${this._uwTaskUrl}/ByUnderwriterId/${id}`
    );
  }

  public async ReassignTask(model: ReassignTask) {
    return await this.postData(`${this._uwTaskUrl}/ReassignTask`, model);
  }
}
