import { Injectable } from '@angular/core';
import { HttpService } from '@shared/services/http-service.service';
import { AppSettingsService } from '@shared/services/app-settings.service';
import { AlertTasksModel } from '@models/Facultative/alertTasksModel';

@Injectable({
  providedIn: 'root'
})
export class FacultativeService {
  private _apiUrl: string;
  private _facSubmissionUrl;

  constructor(private _httpService: HttpService, private _appSettingsService: AppSettingsService) {
    this._apiUrl = this._appSettingsService.GetValue("apiUrl");
    this._facSubmissionUrl = `${this._apiUrl}/FacSubmission`;
  }

  async getAlerts(appId: string, employeeId: string) {
    return await this._httpService.getData<Array<AlertTasksModel>>(
      `${this._facSubmissionUrl}/GetEmployeeInfo/${appId}/${employeeId}`
    );
  }
}
