import { BrowserModule } from "@angular/platform-browser";
import { NgModule, APP_INITIALIZER, Injector } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { AppComponent } from "./app.component";
import { NavMenuComponent } from "./nav-menu/nav-menu.component";
import { HomeComponent } from "./home/home.component";
import { AdminModule } from "@admin/admin.module";
import { FacultativeModule } from "@fac/facultative.module";
import { SharedModule } from "@shared/shared.module";
import { AppRoutingModule } from "./app-routing.module";
import { AuthModule } from "@auth/auth.module";
import { AuthenticationService } from "@auth/service/authentication.service";
import { AppSettingsService } from "@shared/services/app-settings.service";
import { TranslateService } from "@ngx-translate/core";
import { LanguageTranslationService } from "@shared/localization/language-translation.service";

// this method will be called by the angular framework upon startup and will not call the app mouldue unitl it completes
// it will ensure the appsettings and tranlation files are loaded pror to the app being ready
export function initApp(
  authService: AuthenticationService,
  appSettings: AppSettingsService,
  languageTranslation: LanguageTranslationService
) {
  return () => {
    return new Promise((resolve) => {
      // cannot call global UI error banner, the screen will not be published yet.  Use the alert instead to show
      appSettings
        .LoadConfigData("assets/app-settings/appsettings.json") //load app config file
        .then(() => languageTranslation.loadTraslationFile()) // load translation file
        .then(() => authService.login()) // have the user loging
        .then(() => resolve()) // all is done return control back to angular
        .catch((error) =>
          alert(
            "Error connecting to API...Please make sure it is running, message from server: " +
              error.Message
          )
        );
    });
  };
}

@NgModule({
  declarations: [AppComponent, NavMenuComponent, HomeComponent],
  imports: [
    SharedModule,
    AppRoutingModule,
    AdminModule,
    FacultativeModule,
    AuthModule,
    BrowserModule.withServerTransition({ appId: "ng-cli-universal" }),
    FormsModule,
  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: initApp,
      deps: [
        AuthenticationService,
        AppSettingsService,
        LanguageTranslationService,
        TranslateService,
      ],
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {
  static injector: Injector; // global injector service so we can get a serivce reference outside contructor (in JS functions like ag-grid)

  constructor(injector: Injector) {
    AppModule.injector = injector; // store injector to be used later
  }
}
