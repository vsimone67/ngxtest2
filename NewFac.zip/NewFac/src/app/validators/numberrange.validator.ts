
import { Directive, OnInit, forwardRef, Input } from '@angular/core';
import { NG_VALIDATORS, Validator, FormControl, AbstractControl} from '@angular/forms';

@Directive({
  selector: '[appNumberRangeValidator]',
  providers: [
    {provide: NG_VALIDATORS, useExisting: NumberRangeValidatorDirective, multi: true}
  ]
})
export class NumberRangeValidatorDirective implements Validator {

  @Input("lowRange") lowRange:number
  @Input("highRange") highRange:number


 validate(c:AbstractControl){
   let v: number = +c.value;

   if (c.value ===''){
    return {'nrv_required': 'Field is Required'}
   }

   if (isNaN(v)){
     return {'nrv_nonNumeric': 'Field is Not Numeric'}
   }

   console.log(v+':'+this.lowRange+':'+this.highRange+':'+(v < this.lowRange || v > this.highRange));

   if (v < this.lowRange || v > this.highRange){
    return {'nrv_outOfRange': 'Number must be between '+this.lowRange+' and '+this.highRange}
  }

  return null;
}
}

