import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html"
})
export class HomeComponent implements OnInit {
  public boobat: string = "45DAED42-F01A-4865-877B-8FDEBB3101B3";
  constructor() {}
  async ngOnInit() {}
}
