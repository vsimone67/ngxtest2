import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '@auth/service/auth-guard';
import { HomeComponent } from './home/home.component'
import { Role } from '@models/Auth/role';
const routes: Routes = [
    { path: '', data: { breadcrumb: null, roles: [Role.Facultative] }, component: HomeComponent, canActivate: [AuthGuard] },
    { path: 'home', data: { breadcrumb: null, roles: [Role.Facultative] }, component: HomeComponent, canActivate: [AuthGuard] }
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { useHash: true })],
    exports: [RouterModule]
})
export class AppRoutingModule { }
