﻿/* Auto Generated */

import { BaseModel } from "./baseModel"

export interface FacClientRatingModel extends BaseModel {
    clientRatingId: any;
    clientBenefitTypeId?: any;
    baseRatingId?: any;
    flatExtraAmountId?: any;
    flatExtraYearsId?: any;
    exclusionsId?: any;
    facApplicantId: any;
}
