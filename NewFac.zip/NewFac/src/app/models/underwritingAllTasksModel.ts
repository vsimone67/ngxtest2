﻿/* Auto Generated */

export interface UnderwritingAllTasksModel {
    underwriterId: any;
    uWName: string;
    taskId: any;
    generaliFacCessionNumber: string;
    applicantName: string;
    companyName: string;
    benefits: string;
    issueAmount?: number;
    receivedDate?: Date;
    taskAssignedDate: Date;
    taskType: string;
    alertStatus: string;
    facApplicantId: any;
    facAppStatus: string;
    facSubStatus: string;
    languageName: string;
    lob: string;
    seriesName: string;
    prioritizationId?: number;
    prioritizationScore?: number;
    notes: string;
}
