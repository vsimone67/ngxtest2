﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface DocumentGroupMemberModel extends BaseModel {
  groupId: any;
  documentId: any;
  documentRoleTypeId: any;
  sequenceNumber: any;
}
