﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface DocumentGroupModel extends BaseModel {
  groupId: any;
  groupDescription: any;
  groupName: any;
  groupSubTypeId: any;
  groupTypeId: any;
  parentId: any;
}
