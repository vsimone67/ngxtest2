﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface DocumentCaptureCharlotteCompanyModel extends BaseModel {
  documentCaptureCharlotteCompanyId: any;
  companyCode: any;
  charlotteCompanyName: any;
  companyId: any;
  internalCompanyCode: any;
}
