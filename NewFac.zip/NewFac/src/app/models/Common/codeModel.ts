/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface CodeModel extends BaseModel {
  codeId: any;
  codeCategoryId: any;
  codeDescription: string;
  codeName: string;
  codeValue: string;
  isDefault: boolean;
  sequenceNumber: any;
}
