﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface LabelsByCountryAndLanguageModel extends BaseModel {
  countryCodeId: any;
  languageId: any;
  companyLabel: any;
  applicantLabel: any;
  decisionDateLabel: any;
  cedingCompanyLabel: any;
  attentionLabel: any;
  caseNumberLabel: any;
  receivedLabel: any;
  decisionLabel: any;
  offerLabel: any;
  offerExpiresLabel: any;
  reasonLabel: any;
  reconsiderLabel: any;
  requirementsLabel: any;
  reinsLabel: any;
  amountLabel: any;
  additionalMessageLabel: any;
  phoneLabel: any;
  faxLabel: any;
  emailLabel: any;
}
