﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface NoteGroupMemberModel extends BaseModel {
  groupId: any;
  noteId: any;
}
