﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface DocumentCaptureModel extends BaseModel {
  documentCaptureId: any;
  businessCategoryTypeId: any;
  businessUnitTypeId: any;
  captureSourceTypeId: any;
  captureStatusTypeId: any;
  documentPrefix: any;
  parentId: any;
  documentCaptureCharlotteCompanyId: any;
}
