import { DocumentModel } from "./documentModel";

export interface DocumentListModel extends DocumentModel {
  groupType: string;
  documentCategoryName: string;
  createdByName: string;
}
