﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface NoteModel extends BaseModel {
  noteId: any;
  noteDate: any;
  noteText: any;
}
