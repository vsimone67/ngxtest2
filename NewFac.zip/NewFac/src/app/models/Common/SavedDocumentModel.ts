export interface SavedDocumentModel {
  fileStream: Blob;
  contentType: string;
}
