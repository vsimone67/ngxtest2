﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface CodeCategoryModel extends BaseModel {
  codeCategoryId: any;
  codeCategoryDescription: any;
  codeCategoryName: any;
}
