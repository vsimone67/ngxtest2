﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface DocumentCaptureDetailModel extends BaseModel {
  documentCaptureDetailId: any;
  documentCaptureId: any;
  captureFileName: any;
  captureFilePath: any;
  documentCaptureStatusTypeId: any;
  documentId: any;
  documentTypeId: any;
}
