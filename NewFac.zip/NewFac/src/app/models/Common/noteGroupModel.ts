﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface NoteGroupModel extends BaseModel {
  groupId: any;
  groupDescription: any;
  groupName: any;
  groupSubTypeId: any;
  groupTypeId: any;
  parentId: any;
}
