﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface DocumentModel extends BaseModel {
  documentId: any;
  compressionTypeId: any;
  documentArchiveDate: any;
  documentCategoryId: any;
  documentDescription: any;
  documentName: any;
  documentPassword: any;
  documentReceivedDate: any;
  documentScanDate: any;
  documentStatusId: any;
  documentURL: any;
  encryptionFormatTypeId: any;
  isAdmin: any;
  isCompressed: any;
  isEncrypted: any;
  isPasswordProtected: any;
  mIMESubTypeId: any;
  mIMETypeId: any;
  receiveTypeId: any;
  sourceMediaTypeId: any;
  sequenceNumber: any;
  fileName: any;
}
