﻿/* Auto Generated */

import { CodeCategoryModel } from "./../Common//codeCategoryModel";
import { CodeModel } from "./../Common//codeModel";

export interface CodedValuesModel {
  codeModels: any;
  codeCategories: any;
  selectedCodeCategory: CodeCategoryModel;
  selectedCodeModel: CodeModel;
}
