﻿/* Auto Generated */

export interface SubmissionSearchModel {
    cessionNumber: string;
    policyNumber: string;
    lastName: string;
    firstName: string;
    middleName: string;
    dateOfBirth?: Date;
    searchType: boolean;
    alphaSearchResults: any;
}
