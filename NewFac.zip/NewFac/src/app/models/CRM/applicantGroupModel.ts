﻿/* Auto Generated */

import { TeamAssignmentGroupModel } from ".//teamAssignmentGroupModel";

export interface ApplicantGroupModel {
  teamAssignmentGroupModels: any;
  teamAssignmentGroups: any;
  selectedGroup: TeamAssignmentGroupModel;
  availableEmployees: any;
  assignedEmployees: any;
  availableCompanys: any;
  assignedCompanys: any;
  selectedRadioButton: boolean;
  byCompany: number;
  selectedGroupName: string;
  selectedGroupDescription: string;
  selectedGroupIndex: number;
  selectedGroupTypeIndex: number;
  selectedGroupSubTypeIndex: number;
  selectedGroupId?: any;
  selectedGroupTypeId?: any;
  selectedGroupSubTypeId?: any;
  teamAssignmentGroupTypes: any;
  teamAssignmentGroupSubTypes: any;
}
