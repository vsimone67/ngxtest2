﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface AddressModel extends BaseModel {
  addressId: any;
  addressLine1: any;
  addressLine2: any;
  addressLine3: any;
  addressLine4: any;
  addressTypeId: any;
  attentionTo: any;
  city: any;
  countryId: any;
  demographicInfoGroupId: any;
  isPrimaryAddress: any;
  latitude: any;
  longitude: any;
  postalCode: any;
  postOfficeBox: any;
  provinceId: any;
  stateId: any;
  timeZoneId: any;
  zipCode4: any;
  zipCode5: any;
}
