/* Auto Generated */

import { BaseModel } from "@models/baseModel";
import { UnderwritingSeriesModel } from "@models/CRM/underwritingSeriesModel";

export interface EmployeeUnderwritingSeriesModel extends BaseModel {
    employeeId: any;
    seriesId: any;
    seriesName: string;
    allowDecision: boolean;
    series: UnderwritingSeriesModel;
}
