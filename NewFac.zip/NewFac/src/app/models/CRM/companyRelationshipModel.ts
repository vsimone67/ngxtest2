﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface CompanyRelationshipModel extends BaseModel {
  companyRelationshipId: any;
  childCompanyId: any;
  companyRelationshipNote: any;
  companyRelationshipTypeId: any;
  parentCompanyId: any;
  recursionLevel: any;
}
