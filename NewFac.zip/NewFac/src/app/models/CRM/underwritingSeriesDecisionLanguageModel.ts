﻿/* Auto Generated */

export interface UnderwritingSeriesDecisionLanguageModel {
    decisionLanguageId?: any;
    origDecisionLanguageId?: any;
    seriesId?: any;
    languageId?: any;
    languageName: string;
    createDate?: Date;
    createdBy?: any;
    modifiedDate?: Date;
    modifiedBy?: any;
    rowStatusId?: any;
}
