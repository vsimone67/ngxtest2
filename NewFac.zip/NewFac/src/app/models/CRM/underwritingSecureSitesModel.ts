﻿/* Auto Generated */

export interface UnderwritingSecureSitesModel {
    secureSiteId?: number;
    companyId?: any;
    companyName: string;
    secureSiteURL: string;
    secureSiteFolder: string;
    secureSiteUsername: string;
    secureSitePassword: string;
    sSHHostKey: string;
    transmitTypeId?: any;
    transmitType: string;
    createDate: Date;
    createdBy?: any;
    modifiedDate?: Date;
    modifiedBy?: any;
    rowStatusId?: any;
    isActive?: boolean;
    rowStatus: string;
}
