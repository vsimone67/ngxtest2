﻿/* Auto Generated */

import { BaseModel } from "./../baseModel"

export interface EmployeeModel extends BaseModel {
    employeeId: any;
    anniversaryDate: any;
    costCenterNumber: any;
    dateOfBirth: any;
    demographicInfoGroupId: any;
    domainName: any;
    employeeNumber: any;
    employeeRoleId: any;
    firstName: any;
    genderId: any;
    isOfac: any;
    jobTitle: any;
    lastName: any;
    maritalStatusId: any;
    middleName: any;
    nickName: any;
    personalInterests: any;
    personNotes: any;
    salutationId: any;
    soundexKeyCode: any;
    spouseFirstName: any;
    spouseLastName: any;
    stateOfBirthId: any;
    suffixId: any;
    employeeLastFirstName: any;
}
