/* Auto Generated */

import { BaseModel } from "@models/baseModel";

import { EmployeeUnderwritingCountryModel } from "./employeeUnderwritingCountryModel";
import { EmployeeUnderwritingExcludedCompaniesModel } from "./employeeUnderwritingExcludedCompaniesModel";
import { EmployeeUnderwritingLanguageModel } from "./employeeUnderwritingLanguageModel";
import { EmployeeUnderwritingSeriesModel } from "./employeeUnderwritingSeriesModel";
import { CodeModel } from "@models/Common/codeModel";
import { CompanyModel } from "@models/companyModel";
import { UnderwritingSeriesModel } from "@models/CRM/underwritingSeriesModel";
import { EmployeeModel } from "@models/CRM/employeeModel";

export interface EmployeeUnderwritingModel extends BaseModel {
  employeeId: any;
  dailyFacCaseAssignments: number;
  dailyFacCaseCount: number;
  maximumFacCaseCount: number;
  lastTaskAssignedDate: Date;
  moveToNBShuffler: boolean;
  moveToPaperShuffler: boolean;
  isReadOnly: boolean;
  updateUserDomainName: string;
  employee: EmployeeModel;
  uwName: string;
  employeeUnderwritingCountry: EmployeeUnderwritingCountryModel[];
  employeeUnderwritingExcludedCompanies: EmployeeUnderwritingExcludedCompaniesModel[];
  employeeUnderwritingLanguage: EmployeeUnderwritingLanguageModel[];
  employeeUnderwritingSeries: EmployeeUnderwritingSeriesModel[];
  languages: CodeModel[];
  languagesUsed: CodeModel[];
  companies: CompanyModel[];
  companiesExcluded: CompanyModel[];
  underwritingSeries: UnderwritingSeriesModel[];
}
