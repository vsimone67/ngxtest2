/* Auto Generated */

import { BaseModel } from "@models/baseModel";
import { CodeModel } from "@models/Common/codeModel";

export interface EmployeeUnderwritingCountryModel extends BaseModel {
  employeeId: any;
  countryCodeId: any;
  currencyCodeId: any;
  maximumViewAmount: number;
  criticalIllnessMaxViewAmount: number;
  disabilityMaxViewAmount: number;
  maximumDecisionAmount: number;
  criticalIllnessMaxDecisionAmount: number;
  disabilityMaxDecisionAmount: number;
  allowHighDollarCases: boolean;
  allowJointCases: boolean;
  allowPreviousCases: boolean;
  ltcmaxViewAmount: number;
  ltcmaxDecisionAmount: number;
  minimumViewAmount: number;
  criticalIllnessMinViewAmount: number;
  disabilityMinViewAmount: number;
  ltcminViewAmount: number;
  currency: CodeModel;
  country: CodeModel;
  currencyName: string;
  countryName: string;
}
