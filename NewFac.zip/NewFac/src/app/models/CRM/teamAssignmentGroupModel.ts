﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface TeamAssignmentGroupModel extends BaseModel {
  groupId: any;
  groupDescription: any;
  groupName: any;
  groupSubTypeId: any;
  groupTypeId: any;
  parentId: any;
  groupType: any;
  groupSubType: any;
}
