﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface PhoneNumberModel extends BaseModel {
  phoneNumberId: any;
  accessCode: any;
  areaCode: any;
  countryCode: any;
  demographicInfoGroupId: any;
  exchange: any;
  extension: any;
  isPrimaryPhone: any;
  localNumber: any;
  phoneNumber1: any;
  phoneNumberTypeId: any;
}
