﻿/* Auto Generated */

import { CodeModel } from "@models/Common//codeModel";
import { EmployeeModel } from "./employeeModel";

export interface UnderwritingSeriesCountryModel {
  seriesId?: any;
  seriesName: string;
  countryCodeId: any;
  countryName: string;
  originalSeriesId?: any;
  originalCountryCodeId?: any;
  createDate?: Date;
  createdBy?: any;
  modifiedDate?: Date;
  modifiedBy?: any;
  rowStatusId?: any;
  mIBAuthorized: boolean;
  seriesSupervisorEmployeeId?: any;
  seriesSupervisorEmployeeName: string;
  jumboAmountLimit?: number;
  underwriterAssignable: boolean;
  overLimitAuthorizationId?: any;
  overLimitAuthorizationCode: string;
  isDecisionManuallyHandled: boolean;

  countryCode: CodeModel[];
  overLimitAuthorization: CodeModel[];
  seriesSupervisorEmployee: EmployeeModel[];
}
