/* Auto Generated */

import { UnderwritingSeriesCountryModel } from './underwritingSeriesCountryModel';
import { UnderwritingSeriesLanguageComponent } from '@admin/components';
import { UnderwritingSeriesDecisionLanguageModel } from './underwritingSeriesDecisionLanguageModel';

export interface UnderwritingSeriesModel {
    seriesId?: any;
    seriesName: string;
    originalSeriesName: string;
    seriesSequence: number;
    createDate?: Date;
    createdBy?: any;
    modifiedDate?: Date;
    modifiedBy?: any;
    rowStatusId?: any;
    seriesSortSequence: number;
    seriesLanguages: string;
    languagesSelectedIds: any;

    underwritingSeriesCountry: UnderwritingSeriesCountryModel[];
    underwritingSeriesLanguage: UnderwritingSeriesDecisionLanguageModel[];
}
