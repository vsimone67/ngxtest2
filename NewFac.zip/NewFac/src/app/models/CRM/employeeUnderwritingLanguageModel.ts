﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface EmployeeUnderwritingLanguageModel extends BaseModel {
  employeeId: any;
  languageTypeId: any;
}
