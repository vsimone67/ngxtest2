﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface TeamAssignmentGroupMemberModel extends BaseModel {
  groupId?: any;
  employeeId?: any;
  roleTypeId?: any;
  employee: any;
}
