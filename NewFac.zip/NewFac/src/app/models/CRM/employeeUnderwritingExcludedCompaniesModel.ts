﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface EmployeeUnderwritingExcludedCompaniesModel extends BaseModel {
  employeeId: any;
  excludedCompanyId: any;
}
