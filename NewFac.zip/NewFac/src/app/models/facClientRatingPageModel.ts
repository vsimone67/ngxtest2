﻿/* Auto Generated */

export interface FacClientRatingPageModel {
    facClientRatingDisplayModel: any;
    codeCategoryModel: any;
    selectedCodeCategoryId?: any;
}
