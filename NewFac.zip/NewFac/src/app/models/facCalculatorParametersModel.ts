﻿/* Auto Generated */

export interface FacCalculatorParametersModel {
    uGOScoresParamFieldsId: number;
    displayFieldName: string;
    defaultValue: string;
    paramOrder?: number;
    paramActive: boolean;
    paramDelimiter: string;
    createdDate?: Date;
    createdBy?: any;
    modifiedDate?: Date;
    modifiedBy?: any;
    rowStatusId?: any;
}
