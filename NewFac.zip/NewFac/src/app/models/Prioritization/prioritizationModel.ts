﻿/* Auto Generated */

export interface PrioritizationModel {
    prioritizationId: number;
    prioritizationTypeName: string;
    sortOrder: number;
    symbol: string;
    color: string;
    displayPrioritization: boolean;
    originalPrioritizationTypeName: string;
}
