
export enum Role {
      
    Facultative = "Facultative",
    FacultativeOpinion = "FacultativeOpinion",
    FacultativeManager = "FacultativeManager",
    NewSubmission = "NewSubmission",
    CaptureDocument = "CaptureDocument"

}
