import { Role } from "@models/Auth/role";

export class User {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  roles: Array<Role>;
  token?: string;
  userId: string;
}
