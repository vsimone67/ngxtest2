"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Role;
(function (Role) {
    Role["Facultative"] = "Facultative";
    Role["FacultativeOpinion"] = "FacultativeOpinion";
    Role["FacultativeManager"] = "FacultativeManager";
    Role["NewSubmission"] = "NewSubmission";
    Role["CaptureDocument"] = "CaptureDocument";
})(Role = exports.Role || (exports.Role = {}));
//# sourceMappingURL=role.js.map