﻿/* Auto Generated */

export interface ImpairmentImpairmentCodeModel {
    impairmentCodeId?: any;
    impairmentId?: any;
    impairmentName: string;
    originalImpairmentName: string;
    impairmentUWGuideURL: string;
    sortOrder: number;
    displayImpairment: boolean;
    facApplicantImpairmentImpairmentCodeCount: number;
}
