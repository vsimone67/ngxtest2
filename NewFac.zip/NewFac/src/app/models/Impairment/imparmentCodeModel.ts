﻿/* Auto Generated */

import { BaseModel } from "./../baseModel"

export interface ImparmentCodeModel extends BaseModel {
    impairmentCodeId: any;
    impairmentId?: any;
    impairmentName: string;
    isImpairmentAka?: boolean;
    sortOrder: number;
}
