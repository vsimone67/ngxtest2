﻿/* Auto Generated */

export interface ImpairmentModel {
    impairmentId?: any;
    impairmentUWGuideURL: string;
    isAdjustment?: boolean;
    isCredit: boolean;
    isFlatExtra: boolean;
    isRequiresDescription: boolean;
}
