﻿import { UnderwritingAllTasksModel } from "./underwritingAllTasksModel";

/* Auto Generated */

export interface UnderwritingTeamsTaskTotalsModel {
  underwriter: string;
  employeeId: any;
  maximumFacCaseCount?: number;
  newWithin24Hrs?: number;
  new24To48?: number;
  new48Hrspls?: number;
  additionalPapers?: number;
  otherAlertsToday?: number;
  totalActiveTasks?: number;
  newAssignedToday?: number;
  addAssignedToday?: number;
  outstandingAlerts?: number;
  newCompletedToday?: number;
  addCompletedToday?: number;
  opinionOnlyDecisionToday?: number;
  opinionOnlyCasesCompletedToday?: number;
  underwritertasks: Array<UnderwritingAllTasksModel>;
}
