﻿/* Auto Generated */

export interface BaseModel {
    createDate?: Date;
    createdBy?: any;
    modifiedDate?: Date;
    modifiedBy?: any;
    moduleReference?: any;
    rowStatusId?: any;
}
