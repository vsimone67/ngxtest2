﻿/* Auto Generated */

export interface UGOScoresModel {
    facApplicantId?: any;
    scoreNumber?: number;
    ugoversion: string;
    prioritizationScore?: number;
    scriptParms: string;
    scriptErrors: string;
    createDate?: Date;
    createdBy?: any;
    classificationId?: number;
    descriptiveText: string;
    calculatorResponse: string;
}
