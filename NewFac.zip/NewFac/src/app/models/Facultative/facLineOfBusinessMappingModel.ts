/* Auto Generated */

import { BaseModel } from "./../baseModel"

export interface FacLineOfBusinessMappingModel extends BaseModel {
    facLineOfBusinessId?: any;
    facBenefitTypeId?: any;
    facBenefitTypeName: string;
    isBaseBenefit: boolean;
}
