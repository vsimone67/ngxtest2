﻿/* Auto Generated */

export interface FacApplicantGroupingModel {
    facApplicantId: any;
    relatedFacApplicantId: any;
    createDate: Date;
    createdBy: any;
}
