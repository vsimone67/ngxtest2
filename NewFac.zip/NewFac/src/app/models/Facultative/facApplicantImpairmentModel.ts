﻿/* Auto Generated */

export interface FacApplicantImpairmentModel {
    facApplicantImpairmentId?: any;
    debitTypeId?: any;
    debitTypeCodeName: string;
    extraPremiumAmount?: number;
    extraPremiumYearsTypeId?: any;
    facApplicantId?: any;
    impairmentCodeId?: any;
    impairmentCodeName: string;
    impairmentText: string;
    isConverted?: boolean;
    isPrimary?: boolean;
    createDate?: Date;
    createdBy?: any;
    modifiedDate?: Date;
    modifiedBy?: any;
    moduleReference?: any;
    rowStatusId?: any;
    extraPremiumYearsCode: any;
    debitTypeCode: any;
}
