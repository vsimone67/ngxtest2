﻿/* Auto Generated */

export interface FacSubmissionModel {
    facSubmissionId?: any;
    applicationDate?: Date;
    cedingCompanyId?: any;
    companyContactGroupId?: any;
    facSubmissionStatusDate?: Date;
    facSubmissionStatusTypeId?: any;
    isConverted?: boolean;
    isJointCase?: boolean;
    lobTypeId?: any;
    nmlCaseControlNumber: string;
    policyCededTypeId: any;
    policyIssueDate?: Date;
    policyNumber: string;
    policyNumberAdditional1: string;
    policyNumberAdditional2: string;
    receivedDate?: Date;
    systemClassTypeId?: any;
    underwritingRegionCodeTypeId?: any;
    createDate?: Date;
    createdBy?: any;
    modifiedDate?: Date;
    modifiedBy?: any;
    moduleReference?: any;
    rowStatusId?: any;
    cedingCompanyAttentionName: string;
    currencyCodeId?: any;
    countryCodeId?: any;
    seriesCodeId?: any;
    languageId?: any;
    newBusinessEmployeeId?: any;
    productTypeId?: any;
    prioritizationId?: number;
    signedDate?: Date;
}
