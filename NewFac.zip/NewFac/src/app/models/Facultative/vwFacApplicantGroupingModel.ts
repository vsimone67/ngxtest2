﻿/* Auto Generated */

export interface VwFacApplicantGroupingModel {
    facApplicantId: any;
    relatedFacApplicantId: any;
    generaliFacCessionNumber?: number;
    applicantName: string;
    cedingCompanyName: string;
    cededAmount?: number;
    issueAmount?: number;
}
