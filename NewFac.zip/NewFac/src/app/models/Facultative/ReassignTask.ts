export interface ReassignTask {

    taskId: any;
    reassignedUnderwriterId: any;
}