/* Auto Generated */

import { BaseModel } from "./../baseModel"

export interface FacApplicantBenefitModel extends BaseModel {
    facApplicantBenefitId?: any;
    facApplicantId?: any;
    cededAmount?: number;
    facBenefitTypeId?: any;
    facBenefitTypeName: string;
    issueAmount?: number;
}
