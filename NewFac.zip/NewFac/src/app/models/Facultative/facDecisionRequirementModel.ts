﻿/* Auto Generated */

import { BaseModel } from "./../baseModel";
import { CodeModel } from "./../Common//codeModel";

export interface FacDecisionRequirementModel extends BaseModel {
  facDecisionId: any;
  facRequirementId: any;
  requirementStatusTypeId: any;
  decision: CodeModel;
  requirementType: CodeModel;
  requirementStatus: CodeModel;
}
