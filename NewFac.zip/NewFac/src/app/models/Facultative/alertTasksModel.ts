﻿/* Auto Generated */

import { BaseModel } from "./../baseModel";
import { CodeModel } from "./../Common//codeModel";
import { EmployeeModel } from "./../CRM/employeeModel";

export interface AlertTasksModel extends BaseModel {
  alertTaskId: any;
  assessmentTaskId: any;
  employeeId: any;
  alertTypeId: any;
  alertStatusId: any;
  alertCompletionDate?: Date;
  assignedToName: string;
  alertStatus: CodeModel;
  alertType: CodeModel;
  createdBy: EmployeeModel;
  assignedTo: EmployeeModel;
}
