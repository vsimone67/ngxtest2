﻿/* Auto Generated */

import { BaseModel } from "./../baseModel";
import { CodeModel } from "./../Common//codeModel";
import { FacApplicantImpairmentModel } from "./facApplicantImpairmentModel";

export interface FacDecisionExtraPremiumModel extends BaseModel {
  facDecisionId: any;
  facImpairmentId: any;
  extraPremiumAmount: number;
  extraPremiumYearsTypeId: any;
  extraPremiumCodeValue: CodeModel;
  imparment: any;
  applicantImparment: FacApplicantImpairmentModel;
}
