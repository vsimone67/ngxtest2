﻿/* Auto Generated */

export interface FacAssessmentModel {
    facAssessmentId?: any;
    beneficiaryTypeId?: any;
    bmiDebitTypeId?: any;
    bpDebitTypeId?: any;
    bpDiastolic?: number;
    bpSystolic?: number;
    cholesterol?: number;
    cholesterolDebitTypeId?: any;
    cholesterolHdlRatio?: number;
    cholesterolHdlRatioDebitTypeId?: any;
    facApplicantId?: any;
    heightTotalInches?: number;
    incomeAmount?: number;
    inforceAmount?: number;
    insurancePurposeId?: any;
    isBmiPrimary?: boolean;
    isBpPrimary?: boolean;
    isCholesterolHdlRatioPrimary?: boolean;
    isCholesterolPrimary?: boolean;
    isConverted?: boolean;
    isFinanciallyAcceptable?: boolean;
    isPotentialJumbo?: boolean;
    netWorthAmount?: number;
    pendingAllCompaniesAmount?: number;
    toBeReplacedAmount?: number;
    ultimateTotalLineAmount?: number;
    weightBmi?: number;
    weightPounds?: number;
    createDate?: Date;
    createdBy?: any;
    modifiedDate?: Date;
    modifiedBy?: any;
    moduleReference?: any;
    rowStatusId?: any;
    heightFeet?: number;
    heightInches?: number;
}
