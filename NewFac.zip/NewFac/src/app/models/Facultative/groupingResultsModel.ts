﻿/* Auto Generated */

export interface GroupingResultsModel {
    facApplicantId: any;
    facGroupingResults: any;
}
