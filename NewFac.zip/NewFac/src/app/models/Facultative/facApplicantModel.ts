﻿/* Auto Generated */

import { FacSubmissionModel } from "./facSubmissionModel"
import { UGOScoresModel } from "./uGOScoresModel"
import { PersonModel } from "./../AlphaSearch/personModel"
import { FacClientRatingModel } from "./../facClientRatingModel"
import { FacAssessmentModel } from "./facAssessmentModel"

export interface FacApplicantModel {
    facApplicantId?: any;
    documentGroupId?: any;
    facExcessTypeId?: any;
    facStatusTypeId?: any;
    facStatusDate?: Date;
    facSubmissionId?: any;
    generaliFacCessionNumber?: number;
    generaliFacControlNumber?: number;
    insuredIssueAge?: number;
    isJointPrimary?: boolean;
    isMibAuthorized?: boolean;
    isMibInformationViewed?: boolean;
    isOfac?: boolean;
    isPriorSubmissionViewed?: boolean;
    isReconsideration?: boolean;
    isReinstatement?: boolean;
    nmlClassCodeId?: any;
    noteGroupId?: any;
    teamAssignmentGroupId?: any;
    tobaccoUserTypeId?: any;
    underwriterOfRecordId?: any;
    workflowInstanceId?: any;
    createDate?: Date;
    createdBy?: any;
    modifiedDate?: Date;
    modifiedBy?: any;
    moduleReference?: any;
    rowStatusId?: any;
    workflowCurrentStatus: string;
    priorAssignedFacAppId?: any;
    isCaudreviewRequired?: boolean;
    isUnlinkedViewed: boolean;
    residencePostalCode: string;
    governmentId: string;
    occupation: string;
    documentPageCount?: number;
    requestMIB?: boolean;
    facSubmissionModel: FacSubmissionModel;
    ugoScoresModel: UGOScoresModel;
    personModel: PersonModel;
    facClientRatingModel: FacClientRatingModel;
    facApplicantBenefitModels: any;
    facAssessmentModel: FacAssessmentModel;
    facApplicantImpairmentsModels: any;
    facRequirementModels: any;
    facCaseCommentModels: any;
    groupingCessions: string;
    assignEmployeeModels: any;
    isNew: boolean;
    underwriterAssignable: boolean;
    facBenefitsList: any;
    updateUserDomainName: string;
    caseCommentText: string;
}
