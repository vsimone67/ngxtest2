﻿/* Auto Generated */

export interface FacRequirementModel {
    facRequirementId?: any;
    facApplicantId?: any;
    isConverted?: boolean;
    requirementActivityDate?: Date;
    requirementText: string;
    requirementTypeId?: any;
    requirementStatusTypeId?: any;
    createDate?: Date;
    createdBy?: any;
    modifiedDate?: Date;
    modifiedBy?: any;
    moduleReference?: any;
    rowStatusId?: any;
    requirementStatusCode: any;
    requirementTypeCode: any;
}
