/* Auto Generated */

import { BaseModel } from "./../baseModel"

export interface FacCaseCommentModel extends BaseModel {
    facCaseCommentId?: any;
    facApplicantId?: any;
    caseCommentText: string;
    isConverted?: boolean;
    createdEmployee: any;
    commentCreateByName: string;
}
