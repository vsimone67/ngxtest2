﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface ApplicantGroupMemberModel extends BaseModel {
  applicantGroupMemberId: any;
  cancelDate: any;
  effectiveDate: any;
  applicantGroupId: any;
  insuredGroupId: any;
  facApplicantId: any;
}
