﻿/* Auto Generated */

import { BaseModel } from "@models/baseModel";

export interface ApplicantGroupModel extends BaseModel {
  applicantGroupId: any;
}
