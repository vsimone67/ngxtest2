﻿/* Auto Generated */

import { BaseModel } from "./baseModel"

export interface FacClientRatingDisplayModel extends BaseModel {
    codeId?: any;
    codeCategoryId?: any;
    codeCategoryName: string;
    codeDescription: string;
    codeName: string;
    codeValue: string;
    isDefault: boolean;
    sequenceNumber: number;
    isDisplayed?: boolean;
}
