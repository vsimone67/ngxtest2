﻿/* Auto Generated */

export interface PersonModel {
    personId?: any;
    cancelDate?: Date;
    countryOfBirthId?: any;
    countryOfResidenceId?: any;
    dateOfBirth?: Date;
    effectiveDate?: Date;
    firstName: string;
    genderId?: any;
    insuredStatusId?: any;
    isActive?: boolean;
    isConverted?: boolean;
    isOfac?: boolean;
    lastName: string;
    middleInitial: string;
    priorInsuredId?: any;
    provinceOfBirthId?: any;
    provinceOfResidenceId?: any;
    reportingFirstName: string;
    reportingLastName: string;
    soundexKeyCode: string;
    stateOfBirthId?: any;
    stateOfResidenceId?: any;
    titleNamePrefix: string;
    titleNameSuffix: string;
    createDate?: Date;
    createdBy?: any;
    modifiedDate?: Date;
    modifiedBy?: any;
    moduleReference?: any;
    rowStatusId?: any;
    cessionHeaderId?: any;
    controlNumber?: number;
}
