﻿/* Auto Generated */

export interface PersonGroupMemberModel {
    personGroupMemberId?: any;
    personGroupId?: number;
    personId?: any;
    memberId?: any;
    alphaSearchTypeId?: any;
    cancelDate?: Date;
    effectiveDate?: Date;
}
