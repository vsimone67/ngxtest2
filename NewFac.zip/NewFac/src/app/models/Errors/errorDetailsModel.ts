﻿/* Auto Generated */

export interface ErrorDetailsModel {
    statusCode: number;
    message: string;
}
