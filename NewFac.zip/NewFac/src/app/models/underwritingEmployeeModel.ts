﻿/* Auto Generated */

export interface UnderwritingEmployeeModel {
    employeeId: any;
    firstName: string;
    lastName: string;
    dailyFacCaseCount: number;
    maximumFacCaseCount: number;
    lastTaskAssignedDate?: Date;
}
