"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SiteConstants;
(function (SiteConstants) {
    SiteConstants["UserToken"] = "currentUser";
})(SiteConstants = exports.SiteConstants || (exports.SiteConstants = {}));
//# sourceMappingURL=site-constants.js.map