export enum SiteConstants {
  UserToken = "currentUser",
  savedLocale = "locale",
  savedLanguageParameters = "languageParameters",
}

export const supportedLanguages = [
  { locale: "en", name: "English" },
  { locale: "fr", name: "Français" },
  { locale: "ja", name: "日本語" },
  { locale: "ru", name: "русский" },
  { locale: "tr", name: "Türkçe" },
];
