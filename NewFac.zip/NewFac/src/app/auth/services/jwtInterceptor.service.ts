import { Injectable } from "@angular/core";
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
} from "@angular/common/http";
import { Observable } from "rxjs";
import { User } from "@models/Auth/user";
import { SiteConstants } from "@models/Constants/site-constants";
import { LocalStorageService } from "@shared/services/localStorage-service";

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
  constructor(private lStorage: LocalStorageService) {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    // add auth header with jwt if user is logged in and request is to api url
    var currentUser: User = JSON.parse(
      this.lStorage.getValue(SiteConstants.UserToken)
    );

    const isLoggedIn = currentUser && currentUser.token;

    if (isLoggedIn) {
      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${currentUser.token}`,
        },
      });
    }

    return next.handle(request);
  }
}
