import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";
import { map } from "rxjs/operators";
import { User } from "@models/Auth/user";
import { HttpService } from "@shared/service/http-service.service";
import { AppSettingsService } from "@shared/service/app-settings.service";
import { SiteConstants } from "@models/Constants/site-constants";
import { LocalStorageService } from "@shared/services/localStorage-service";

@Injectable({ providedIn: "root" })
export class AuthenticationService {
  private _apiUrl: string;

  constructor(
    private _httpService: HttpService,
    private _appSettingsService: AppSettingsService,
    private lStorage: LocalStorageService
  ) {}

  async login() {
    this._apiUrl = this._appSettingsService.GetValue("apiUrl");

    var user = await this._httpService.getData<User>(
      `${this._apiUrl}/Authorize/login`
    );
    if (user && user.token) {
      this.lStorage.setValue(SiteConstants.UserToken, JSON.stringify(user));
    }
  }

  logout() {
    // remove user from local storage to log user out
    this.lStorage.removeItem(SiteConstants.UserToken);
  }
}
