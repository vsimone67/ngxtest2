import { Injectable } from "@angular/core";
import {
  Router,
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
} from "@angular/router";
import { AuthenticationService } from "../services/authentication.service";
import { User } from "@models/Auth/user";
import { SiteConstants } from "@models/Constants/site-constants";
import { JwtHelperService } from "@auth0/angular-jwt";
import { LocalStorageService } from "@shared/services/localStorage-service";

@Injectable({ providedIn: "root" })
export class AuthGuard implements CanActivate {
  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private lStorage: LocalStorageService
  ) {}

  canActivate(route: ActivatedRouteSnapshot) {
    var currentUser: User = JSON.parse(
      this.lStorage.getValue(SiteConstants.UserToken)
    );
    var isUserInRole = false;
    var jwtHelper = new JwtHelperService();

    if (currentUser && currentUser.token) {
      var isExpired = jwtHelper.isTokenExpired(currentUser.token);

      if (isExpired) {
        async () => await this.authenticationService.login();
      }
      //go through all the roles a user belongs to and see if they are allowed to access this route
      for (var i = 0; i < currentUser.roles.length; i++) {
        var role = currentUser.roles[i];

        if (route.data.roles.indexOf(role) !== -1) {
          isUserInRole = true;
          break;
        }
      }
    }

    if (!isUserInRole) {
      this.router.navigate(["forbidden"]);
    }

    return isUserInRole;
  }
}
