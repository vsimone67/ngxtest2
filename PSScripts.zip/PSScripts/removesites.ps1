Import-Module WebAdministration

Remove-WebSite -Name ApiGateway
Remove-WebSite -Name AssumedService
Remove-WebSite -Name RetroService
Remove-WebSite -Name RetroPricingService
Remove-WebSite -Name ClaimsService
Remove-WebSite -Name AuthenticationService
Remove-WebSite -Name CrmService
Remove-WebSite -Name TreatyService
Remove-WebSite -Name CommonService
Remove-WebSite -Name WatchDog

Remove-Item "IIS:\SslBindings\*!4350"
Remove-Item "IIS:\SslBindings\*!4351"
Remove-Item "IIS:\SslBindings\*!4352"
Remove-Item "IIS:\SslBindings\*!4353"
Remove-Item "IIS:\SslBindings\*!4354"
Remove-Item "IIS:\SslBindings\*!4355"
Remove-Item "IIS:\SslBindings\*!4356"
Remove-Item "IIS:\SslBindings\*!4357"
Remove-Item "IIS:\SslBindings\*!4358"
Remove-Item "IIS:\SslBindings\*!4359"
