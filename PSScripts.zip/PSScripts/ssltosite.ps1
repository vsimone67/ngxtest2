Param(
    [Parameter(Mandatory = $True, Position = 1)]
    [string]$sslCertificate,  
    [Parameter(Mandatory = $True, Position = 2)]
    [string]$sslPort
)
 
Import-Module WebAdministration

$SSLCert = Get-ChildItem -Path "cert:\LocalMachine\My" | Where-Object { $_.subject -like $sslCertificate }
New-Item "IIS:\SslBindings\*!$sslport" -value $SSLCert 