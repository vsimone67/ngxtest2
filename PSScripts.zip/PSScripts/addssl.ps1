$certificate = "CN=USVDEVFACAS01"

./ssltosite.ps1 $certificate 4350
./ssltosite.ps1 $certificate 4351
./ssltosite.ps1 $certificate 4352
./ssltosite.ps1 $certificate 4353
./ssltosite.ps1 $certificate 4354
./ssltosite.ps1 $certificate 4355
./ssltosite.ps1 $certificate 4356
./ssltosite.ps1 $certificate 4357
./ssltosite.ps1 $certificate 4358
./ssltosite.ps1 $certificate 4359
./ssltosite.ps1 $certificate 4363
./ssltosite.ps1 $certificate 4364
./ssltosite.ps1 $certificate 4365
./ssltosite.ps1 $certificate 4369

