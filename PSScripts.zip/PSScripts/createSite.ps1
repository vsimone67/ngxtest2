Param(
    [Parameter(Mandatory = $True, Position = 1)]
    [string]$siteName ,  
    [Parameter(Mandatory = $True, Position = 2)]
    [int]$sitePort ,
    [Parameter(Mandatory = $True, Position = 3)]
    [int]$sslPort,
    [Parameter(Mandatory = $True, Position = 4)]
    [string]$userName,
    [Parameter(Mandatory = $True, Position = 5)]
    [string]$password,
    [Parameter(Mandatory = $True, Position = 6)]
    [bool]$windowsAuthentication,
    [Parameter(Mandatory = $True, Position = 7)]
    [bool]$anonmyousAuthentication

)
 
Import-Module WebAdministration

$iisAppPoolName = $siteName
$iisAppPoolDotNetVersion = ""
$iisAppName = $siteName
$directoryPath = "D:\webapps\services\" + $siteName
$port = $sitePort
$location = (Get-Location) 

#navigate to the app pools root
Set-Location IIS:\AppPools\

#check if the app pool exists
if (!(Test-Path $iisAppPoolName -pathType container)) {
    #create the app pool
    $appPool = New-Item $iisAppPoolName
    $appPool | Set-ItemProperty -Name "managedRuntimeVersion" -Value $iisAppPoolDotNetVersion
    $appPool | Set-ItemProperty -Name processModel -value @{userName = $userName; password = $password; identitytype = 3 }
}

#navigate to the sites root
Set-Location IIS:\Sites\

#check if the site exists
if (Test-Path $iisAppName -pathType container) {
    return
}

# check to see of the directory exists, if it does not create it
if (-not (Test-Path $directoryPath)) {
    New-Item -Path $directoryPath -ItemType Directory
}

$binding = "*:" + $port + ":"
$sslbinding = "*:" + $sslport + ":"
$iisApp = New-Item $iisAppName -bindings @(@{protocol = "http"; bindingInformation = $binding }, @{protocol = "https"; bindingInformation = $sslbinding })  -physicalPath $directoryPath
$iisApp | Set-ItemProperty -Name "applicationPool" -Value $iisAppPoolName

# Set the windows and anonmyous authentication for the site
Set-WebConfigurationProperty -filter "/system.webServer/security/authentication/windowsAuthentication" -name enabled -value $windowsAuthentication -PSPath IIS:\ -location $iisAppName
Set-WebConfigurationProperty -filter "/system.webServer/security/authentication/anonymousAuthentication" -name enabled -value $anonmyousAuthentication -PSPath IIS:\ -location $iisAppName
#Remove-IISSite
# add SSL port

Set-Location $location
Write-Host "Site" $iisAppName "has been created on port" $port