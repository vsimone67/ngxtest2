$user = "eu\ususivi"
$password = "Scor2021"

./createSite.ps1 WatchDog 3350 4350 $user $password $True $True
./createSite.ps1 ApiGateway 3351 4351 $user $password $True $True
./createSite.ps1 AssumedService 3352 4352 $user $password $True $True
./createSite.ps1 RetroService 3353 4353 $user $password $True $True
./createSite.ps1 RetroPricingService 3354 4354 $user $password $True $True
./createSite.ps1 ClaimsService 3355 4355 $user $password $True $True
./createSite.ps1 AuthenticationService 3356 4356 $user $password $True $False
./createSite.ps1 CrmService 3357 4357 $user $password $True $True
./createSite.ps1 TreatyService 3358 4358 $user $password $True $True
./createSite.ps1 CommonService 3359 4359 $user $password $True $True
./createSite.ps1 AssumedAggregatorService 3363 4363 $user $password $True $True
./createSite.ps1 RetroAggregatorService 3364 4364 $user $password $True $True
./createSite.ps1 RollBackService 3365 4365 $user $password $True $True
./createSite.ps1 RetroHub 3369 4369 $user $password $True $True
